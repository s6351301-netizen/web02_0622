<?php include_once "db.php";

/* 依分類回傳文章列表（供前台「分類網誌」以 AJAX 載入） */
$list = $News->all(['type' => $_GET['type']]);

foreach ($list as $l) {
    $title = htmlspecialchars($l['title'], ENT_QUOTES, 'UTF-8');
    $good  = (int) $l['good'];
    $id    = (int) $l['id'];

    echo "<button type='button' class='list-group-item list-group-item-action d-flex align-items-center gap-3 py-3' onclick='getPost($id)'>";
    echo   "<i class='bi bi-file-earmark-text text-primary'></i>";
    echo   "<span class='flex-grow-1 text-start fw-semibold'>$title</span>";
    echo   "<span class='badge text-bg-brand flex-shrink-0'><i class='bi bi-hand-thumbs-up me-1'></i>$good</span>";
    echo   "<i class='bi bi-chevron-right small text-secondary'></i>";
    echo "</button>";
}
