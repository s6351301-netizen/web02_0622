<?php include_once "db.php";

/* 回傳單篇文章內容（供前台「分類網誌」以 AJAX 載入） */
$post = $News->find($_GET['id']);

if (empty($post)) {
    echo "<div class='hp-empty'><i class='bi bi-exclamation-circle'></i>找不到這篇文章</div>";
    return;
}

$title = htmlspecialchars($post['title'], ENT_QUOTES, 'UTF-8');
$type  = htmlspecialchars($post['type'], ENT_QUOTES, 'UTF-8');
$good  = (int) $post['good'];
?>
<header class="border-bottom pb-3 mb-3">
    <span class="badge text-bg-brand mb-2"><i class="bi bi-tag me-1"></i><?= $type ?></span>
    <h2 class="h4 mb-2"><?= $title ?></h2>
    <p class="small hp-text-muted mb-0">
        <i class="bi bi-hand-thumbs-up me-1"></i><?= $good ?> 人說讚
    </p>
</header>
<div class="hp-prose"><?= $post['content'] ?></div>
