/*!
 * 健康促進網 — 前端互動腳本
 * 依賴：Bootstrap 5 bundle（Popper 已內含）、jQuery（既有頁面沿用）
 */
(function () {
    'use strict';

    /* ---------------------------------------------------------------
     * 明暗主題切換（偏好記錄於 localStorage）
     * ------------------------------------------------------------- */
    var STORE_KEY = 'hp-theme';

    function storedTheme() {
        try { return localStorage.getItem(STORE_KEY); } catch (e) { return null; }
    }

    function preferredTheme() {
        return storedTheme() ||
            (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    }

    function applyTheme(theme) {
        document.documentElement.setAttribute('data-bs-theme', theme);
        document.querySelectorAll('[data-hp-theme-icon]').forEach(function (el) {
            el.className = 'bi ' + (theme === 'dark' ? 'bi-sun-fill' : 'bi-moon-stars-fill');
        });
        document.querySelectorAll('[data-hp-theme-toggle]').forEach(function (el) {
            el.setAttribute('aria-label', theme === 'dark' ? '切換為淺色模式' : '切換為深色模式');
            el.setAttribute('title', theme === 'dark' ? '淺色模式' : '深色模式');
        });
    }

    applyTheme(preferredTheme());

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-hp-theme-toggle]');
        if (!btn) return;
        e.preventDefault();
        var next = document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
        try { localStorage.setItem(STORE_KEY, next); } catch (err) { /* 忽略 */ }
        applyTheme(next);
    });

    /* ---------------------------------------------------------------
     * DOM 就緒後的初始化
     * ------------------------------------------------------------- */
    document.addEventListener('DOMContentLoaded', function () {

        /* 捲動時導覽列加上陰影 */
        var navbar = document.querySelector('.hp-navbar');
        var toTop = document.querySelector('.hp-to-top');

        function onScroll() {
            var y = window.scrollY || document.documentElement.scrollTop;
            if (navbar) navbar.classList.toggle('is-stuck', y > 8);
            if (toTop) toTop.classList.toggle('is-visible', y > 320);
        }
        window.addEventListener('scroll', onScroll, { passive: true });
        onScroll();

        /* 回到頂端 */
        if (toTop) {
            toTop.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        /* Tooltip / Popover 自動初始化 */
        if (window.bootstrap) {
            document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
                new bootstrap.Tooltip(el);
            });
            document.querySelectorAll('[data-bs-toggle="popover"]').forEach(function (el) {
                new bootstrap.Popover(el);
            });
        }

        /* 表單前端驗證樣式（Bootstrap validation） */
        document.querySelectorAll('.needs-validation').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    });

    /* ---------------------------------------------------------------
     * 全域提示訊息（取代原生 alert，可自由沿用）
     * ------------------------------------------------------------- */
    var ICONS = {
        success: 'bi-check-circle-fill',
        danger: 'bi-exclamation-octagon-fill',
        warning: 'bi-exclamation-triangle-fill',
        info: 'bi-info-circle-fill'
    };

    window.hpToast = function (message, type, delay) {
        type = type || 'info';
        var host = document.getElementById('hpToastHost');
        if (!host || !window.bootstrap) { window.alert(message); return; }

        var wrap = document.createElement('div');
        wrap.className = 'toast align-items-center border-0 shadow text-bg-' + type;
        wrap.setAttribute('role', 'alert');
        wrap.setAttribute('aria-live', 'assertive');
        wrap.setAttribute('aria-atomic', 'true');
        wrap.innerHTML =
            '<div class="d-flex">' +
            '<div class="toast-body d-flex align-items-center gap-2">' +
            '<i class="bi ' + (ICONS[type] || ICONS.info) + '"></i><span></span>' +
            '</div>' +
            '<button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="關閉"></button>' +
            '</div>';
        wrap.querySelector('span').textContent = message;
        host.appendChild(wrap);

        var toast = new bootstrap.Toast(wrap, { delay: delay || 3200 });
        wrap.addEventListener('hidden.bs.toast', function () { wrap.remove(); });
        toast.show();
    };
})();
