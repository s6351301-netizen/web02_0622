<?php
/**
 * 前台入口
 * ------------------------------------------------------------------
 * 依 ?do= 參數載入 front/ 目錄下對應頁面，找不到時回到首頁。
 */
include_once "./api/db.php";
include_once "./inc/helpers.php";

$do   = $_GET['do'] ?? 'main';
$file = "./front/$do.php";

if (!file_exists($file)) {
    $do   = 'main';
    $file = "./front/main.php";
}

$HP_AREA = 'front';
$HP_PAGE = $HP_FRONT_NAV[$do] ?? $HP_FRONT_EXTRA[$do] ?? $HP_FRONT_NAV['main'];

include "./inc/head.php";
?>

<?php if ($do !== 'main'): ?>
    <div class="hp-page-head hp-fade-up">
        <h1 class="hp-page-title">
            <i class="bi <?= e($HP_PAGE['icon']) ?>" aria-hidden="true"></i>
            <?= e($HP_PAGE['title']) ?>
        </h1>
        <nav aria-label="麵包屑">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house-door me-1"></i>首頁</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= e($HP_PAGE['label']) ?></li>
            </ol>
        </nav>
    </div>
<?php endif; ?>

<div class="hp-fade-up">
    <?php include $file; ?>
</div>

<?php include "./inc/footer.php"; ?>
