# RENEW.md — 健康促進網 介面改版紀錄

> 改版日期：2026-08-11
> 改版目標：**在不改變既有功能的前提下**，將整站視覺與版面重構為現代化、響應式（RWD）的設計，
> 並讓前台與後台具備一致的視覺語言。

---

## 目錄

1. [改版摘要](#1-改版摘要)
2. [新增的檔案與目錄](#2-新增的檔案與目錄)
3. [下載到本機的函式庫](#3-下載到本機的函式庫)
4. [設計系統](#4-設計系統)
5. [Logo 與 Banner](#5-logo-與-banner)
6. [版面架構重構](#6-版面架構重構)
7. [HTML5 語意化標籤](#7-html5-語意化標籤)
8. [各頁面改版明細](#8-各頁面改版明細)
9. [額外的 UI／UX 強化](#9-額外的-uiux-強化)
10. [無障礙與 RWD](#10-無障礙與-rwd)
11. [移除的檔案](#11-移除的檔案)
12. [功能相容性說明](#12-功能相容性說明)
13. [實機驗證結果](#13-實機驗證結果)
14. [後續建議（未執行）](#14-後續建議未執行)

---

## 1. 改版摘要

| 項目 | 改版前 | 改版後 |
| --- | --- | --- |
| CSS 框架 | 自製 `css/css.css`（301 行） | Bootstrap 5.3.8 + 自製主題層 `assets/css/theme.css` |
| DOCTYPE | XHTML 1.0 Transitional | HTML5 |
| 版面寬度 | 固定 `1024px × 768px` | 流動式全版面（`max-width: 1440px`，隨裝置縮放） |
| 行動裝置 | 不支援（無 viewport meta） | 完整 RWD，手機／平板／桌機皆可用 |
| 版面結構 | `div#all` / `div#lef` / `div#main` + 表格排版 | `header` / `nav` / `main` / `aside` / `article` / `footer` 語意化標籤 |
| 導覽方式 | 左側固定連結清單 | 前台：頂部導覽列（手機收合）；後台：側邊欄 + 手機 offcanvas |
| 圖示 | 圖片 | Bootstrap Icons 1.13.1（字型圖示，可縮放） |
| Logo／Banner | `icon/02B01.jpg`（點陣圖） | 全新 SVG 向量識別（`assets/img/`） |
| 深色模式 | 無 | 支援，並記憶使用者偏好 |
| jQuery | 1.9.1（2013 年） | 3.7.1 |

---

## 2. 新增的檔案與目錄

```
assets/
├── css/theme.css          # 主題層：設計代幣、Bootstrap 覆寫、自訂元件
├── js/app.js              # 主題切換、捲動效果、回到頂端、Toast 提示
└── img/
    ├── logo-mark.svg      # 品牌標誌（正方形，導覽列／頁尾用）
    ├── logo.svg           # 完整橫式 Logo（標誌 + 字標）
    ├── favicon.svg        # 瀏覽器頁籤圖示
    └── banner.svg         # 首頁主視覺 Banner

inc/
├── helpers.php            # 共用函式（e()、hp_is()、hp_weekday()…）與選單設定
├── head.php               # 共用頁首（<head>、資訊列、導覽列、公告列）
├── footer.php             # 共用頁尾（網站導覽、聯絡資訊、回到頂端、Toast 容器）
├── admin_nav.php          # 後台側邊選單（桌機側欄與手機 offcanvas 共用）
└── coming_soon.php        # 尚未實作功能的統一提示畫面

vendor/                    # 本機化的第三方函式庫（詳見下一節）

front/know.php             # 前台「講座訊息」頁（原本無此檔案，點選會落回首頁）
back/know.php              # 後台「講座訊息」頁（同上）
back/po.php                # 後台「分類網誌」頁（同上）
```

---

## 3. 下載到本機的函式庫

所有函式庫皆**下載至本機 `vendor/` 目錄**，不依賴 CDN，離線與內網環境皆可正常運作。

| 函式庫 | 版本 | 路徑 |
| --- | --- | --- |
| Bootstrap CSS | 5.3.8（最新穩定版） | `vendor/bootstrap/css/bootstrap.min.css`（含 `.map`、RTL 版） |
| Bootstrap JS | 5.3.8 | `vendor/bootstrap/js/bootstrap.bundle.min.js`（已內含 Popper） |
| Bootstrap Icons | 1.13.1 | `vendor/bootstrap-icons/font/bootstrap-icons.min.css` + `fonts/*.woff2`、`*.woff` |
| jQuery | 3.7.1 | `vendor/jquery/jquery-3.7.1.min.js` |

> jQuery 由 1.9.1 升級至 3.7.1；既有頁面使用的 `$.get` / `$.post` / `$(sel).on()` 等 API
> 在 3.x 中行為一致，已逐頁實測確認無誤。

---

## 4. 設計系統

`assets/css/theme.css` 以 **CSS 自訂屬性（Design Tokens）** 建立設計系統，
再對應到 Bootstrap 的 `--bs-*` 變數，因此只要調整代幣即可全站換色。

**品牌色彩**：以「清新醫療綠 × 沉穩科技藍」為主軸，符合健康促進的主題。

| 代幣 | 值 | 用途 |
| --- | --- | --- |
| `--hp-primary` | `#0d9488` | 主色（按鈕、連結、強調） |
| `--hp-secondary` | `#0369a1` | 漸層輔色 |
| `--hp-accent` | `#65a30d` | 公告列、成長意象 |
| `--hp-on-soft` | 淺色 `#115e59` / 深色 `#5eead4` | 淺底上的品牌前景色（確保雙模式對比度） |
| `--hp-gradient` | 綠 → teal → 藍 135° 漸層 | Logo、主視覺、進度條、側欄選中項 |
| `--hp-radius / -sm / -lg` | `.875 / .5 / 1.25rem` | 統一圓角 |
| `--hp-shadow-xs / -sm / - / -lg` | 四階陰影 | 統一景深層級 |

**字體**：`Noto Sans TC → PingFang TC → Microsoft JhengHei（微軟正黑體）→ system-ui`，
不引用外部字體服務，避免離線環境破版。

**其他覆寫**：按鈕、表單、卡片、表格、分頁、清單、標籤頁、Badge、Breadcrumb、Modal、
Offcanvas 皆已配合品牌色與圓角重新定義。

---

## 5. Logo 與 Banner

原本的 `icon/02B01.jpg`（點陣圖橫幅）與 `icon/02B04.png`（側欄底圖）已不再使用，
改為全新設計的 SVG 向量素材（無限縮放不失真、檔案極小、支援深色背景）。

### Logo（`assets/img/logo-mark.svg`、`logo.svg`、`favicon.svg`）

設計概念三合一：

- **心形**：健康與關懷
- **心電圖脈搏線**：活力、生命徵象與健康監測
- **綠芽**：促進、成長與永續

外框為品牌漸層的圓角方塊，導覽列上的字標「健康促進網」以 CSS 漸層文字呈現
（不依賴 SVG 內嵌中文字型，避免不同系統字型缺字問題），下方搭配英文副標
`HEALTH PROMOTION NETWORK`。

### Banner（`assets/img/banner.svg`）

1600×520 的主視覺，內容包含：漸層天空底、三處柔光暈染、右上點陣紋理（漸隱遮罩）、
橫貫畫面的心電圖脈搏線與脈動點、健走人物剪影、三層底部波浪。
以 `object-fit: cover` 鋪滿 hero 區塊，文字則以 HTML 疊加，確保任何螢幕比例都不會裁切到標題。

---

## 6. 版面架構重構

### 前台（`index.php`）

```
header
 ├─ 資訊列（日期、今日／累積瀏覽、服務信箱、回首頁）
 ├─ 導覽列 sticky-top（Logo、六大選單、深色模式、會員選單）
 └─ 公告跑馬燈
main
 ├─ 頁面標題 + 麵包屑（首頁除外）
 └─ 依 ?do= 載入的內容
footer（品牌簡介、網站導覽、會員服務、聯絡我們、版權）
回到頂端按鈕、Toast 提示容器
```

原本的「左側選單 + 右側捲動框」改為**頂部導覽 + 全寬內容**，內容不再被鎖在
`520px` 高的 `overflow: auto` 方框裡，長文章可直接於頁面捲動閱讀。

### 後台（`admin.php`）

沿用相同的 header／footer，內容區改為典型的儀表板結構：

- **桌機（≥992px）**：左側 sticky 側邊欄（管理功能 + 快速操作）+ 右側內容
- **手機／平板**：側邊欄收進 offcanvas，由導覽列漢堡鈕開啟

後台導覽列加上「後台」徽章與相同的品牌標誌，前後台視覺一致但角色清楚可辨。

---

## 7. HTML5 語意化標籤

| 語意標籤 | 使用位置 |
| --- | --- |
| `<!DOCTYPE html>` / `<html lang="zh-Hant">` | 取代 XHTML 1.0 Transitional |
| `<header>` | 全站頁首（資訊列 + 導覽列 + 公告） |
| `<nav>` | 主選單、後台側欄、麵包屑、分頁 |
| `<main>` | 主要內容區（搭配「跳至主要內容」錨點） |
| `<aside>` | 後台側邊欄、分類網誌的提示方塊 |
| `<article>` | 每一篇文章（首頁專欄、最新文章、人氣文章、分類網誌內容） |
| `<section>` | 首頁各區塊（主視覺、捷徑、精選、健康專欄） |
| `<footer>` | 頁尾與卡片內的中繼資訊列 |
| `<figure>` 概念改以 `<time datetime>` 標註日期 | 文章發佈日期、資訊列日期 |
| `<fieldset>` / `<legend>` | 投票單選題組（語意正確的用法） |
| `<button>` / `<label>` | 取代原本以 `<a>`、`<div>` 假冒的可點擊元素 |

其他一併移除的過時語法：`<marquee>`（改為 CSS 動畫，並支援
`prefers-reduced-motion`）、`<table>` 排版、`align` / `bgcolor` 類屬性、
`<a href="javascript:...">`、大量的 inline `style`。

---

## 8. 各頁面改版明細

### 前台

| 檔案 | 改版內容 |
| --- | --- |
| `front/main.php` | 全新首頁：主視覺 Banner（含即時統計）→ 四張功能捷徑卡 → 最新文章／人氣排行雙欄 → 健康專欄。原本用 jQuery 手刻的四個分頁標籤改為 Bootstrap Nav Pills + Tab Pane，四篇既有內容完整保留並補上出處／日期標頭 |
| `front/po.php` | 左側分類 `list-group` + 右側文章卡片；新增「返回列表」按鈕、載入中轉圈、空狀態畫面。AJAX 端點與函式名稱（`getPosts` / `getPost`）維持不變 |
| `front/news.php` | 表格改為 Accordion：標題 + 分類徽章 + 內容摘要，展開閱讀全文；按讚改為心形膠囊按鈕並顯示已按讚狀態；分頁改用 Bootstrap Pagination（含上／下頁與停用狀態） |
| `front/pop.php` | 改為排行榜卡片列表：名次徽章（前三名金／銀／銅）、人氣比例進度條、按讚狀態。原本的 hover 浮動視窗（手機無法使用）改為 **Modal 燈箱**，可捲動閱讀全文 |
| `front/que.php` | 表格改為問卷卡片格線，顯示開放狀態、累計票數、選項數；未登入時於頁首提示並提供登入捷徑（仍可查看結果） |
| `front/vote.php` | 選項改為可整列點選的 `list-group` + `form-check`，包在 `<fieldset>` 內；加上必填驗證、返回列表與查看結果按鈕；查無問卷時顯示友善空狀態 |
| `front/result.php` | 手刻 `div` 長條圖改為 Bootstrap Progress，最高票加上獎盃標記；票數與百分比計算邏輯完全沿用（含避免分母為零） |
| `front/login.php` | 置中認證卡片、漸層標頭、輸入框圖示、**密碼顯示／隱藏切換**；`alert()` 改為 Toast 提示。登入流程與 API 呼叫順序不變 |
| `front/reg.php` | 四步驟表單加上步驟徽章、`maxlength=12`、Email 型別驗證，以及**即時的兩次密碼一致性提示** |
| `front/forgot.php` | 認證卡片樣式；查詢結果改以警示框呈現（文字以 `.text()` 輸出，避免 HTML 注入） |
| `front/know.php` | **新增**：原本選單點了會落回首頁，現在提供明確的「籌備中」說明與替代入口 |

### 後台

| 檔案 | 改版內容 |
| --- | --- |
| `back/main.php` | 由一行「請選擇管理項目」升級為**儀表板**：會員數／文章數（顯示・隱藏）／問卷數（開放中）／累計按讚四張統計卡、近期瀏覽量長條圖、最近文章清單、四張快速操作卡。全部使用既有資料表，唯讀查詢 |
| `back/acc.php` | 會員列表改為含頭像的表格，管理員標註徽章、密碼以圓點遮罩；刪除加上二次確認；新增會員表單移到右側卡片並加上步驟徽章 |
| `back/news.php` | 顯示欄位改為 **Switch 開關**，列出分類與按讚數；隱藏欄位 `id[]` 移入合法的 `<td>` 內（原本放在 `<tr>` 之間屬無效 HTML）；勾選刪除時才跳出確認；分頁改為 Bootstrap Pagination |
| `back/add_news.php` | 卡片式表單、`needs-validation` 前端驗證、**即時字數統計**、返回列表按鈕 |
| `back/que.php` | 新增問卷的動態選項改為 input-group，**可逐項移除**；問卷列表改為 Switch 即時開關（沿用 `active_que.php`），並顯示選項數與前台結果連結 |
| `back/po.php`、`back/know.php` | **新增**：統一的「功能籌備中」畫面，取代原本靜默落回儀表板的死連結 |

### API

| 檔案 | 改版內容 |
| --- | --- |
| `api/get_posts.php` | 輸出改為 Bootstrap `list-group-item` 按鈕（含圖示與按讚數徽章），標題經 `htmlspecialchars` 跳脫。查詢條件未更動 |
| `api/get_post.php` | 輸出加上分類徽章、標題、按讚數的文章標頭；內容以 `.hp-prose`（`white-space: pre-wrap`）呈現，換行效果與原本的 `nl2br` 一致；查無資料時回傳空狀態 |

> 其餘 API（`db.php`、`chk_acc`、`chk_pw`、`reg`、`forgot`、`logout`、`good`、`vote`、
> `add_que`、`active_que`、`edit_acc`、`edit_news`、`save_news`）**完全未修改**。

---

## 9. 額外的 UI／UX 強化

以下為主動加入、對使用體驗有幫助的設計（皆為附加，不影響原功能）：

1. **深色／淺色模式切換** — 導覽列一鍵切換，偏好存於 `localStorage`，
   首次進站依系統設定判斷；`<head>` 內有防閃爍腳本。
2. **Toast 通知** — `hpToast(訊息, 類型)` 取代生硬的 `alert()`，
   若 Bootstrap 尚未載入會自動退回 `alert()`。
3. **回到頂端按鈕** — 捲動超過 320px 後淡入。
4. **捲動時導覽列加陰影** — 提供層級感。
5. **空狀態畫面** — 沒有文章／問卷／會員時顯示圖示與說明，而非空白表格。
6. **載入中狀態** — 分類網誌 AJAX 期間顯示 spinner。
7. **危險操作二次確認** — 刪除帳號、刪除文章。
8. **首頁即時統計** — 文章數、會員數、問卷數直接呈現於主視覺。
9. **人氣比例視覺化** — 人氣文章以進度條呈現相對熱度。
10. **麵包屑導覽** — 每個內頁都能清楚知道所在位置。
11. **卡片 hover 微互動** — 上浮 + 陰影加深。
12. **列印樣式** — 列印時自動隱藏導覽、頁尾與裝飾元素。
13. **`prefers-reduced-motion` 支援** — 使用者若要求減少動態，動畫自動停用。

---

## 10. 無障礙與 RWD

**無障礙（a11y）**

- 「跳至主要內容」skip link（鍵盤 Tab first stop）
- 所有互動元素改用 `<button>` / `<a>`，可鍵盤操作
- `aria-label`、`aria-current="page"`、`aria-expanded`、`aria-controls`、
  `role="progressbar"` 與 `aria-valuenow` 等屬性完整標註
- 表單 `<label for>` 與輸入框正確關聯（不顯示的標籤使用 `.visually-hidden`）
- 圖示按鈕皆有文字說明；裝飾性圖片標記 `alt="" aria-hidden="true"`
- 深色模式下的品牌前景色另行定義（`--hp-on-soft`），避免深底深字

**RWD 斷點行為**

| 寬度 | 前台 | 後台 |
| --- | --- | --- |
| < 576px | 導覽收合為漢堡選單、品牌縮小、統計卡單欄、資訊列僅留日期 | 同左；表格橫向捲動 |
| 576 – 991px | 捷徑卡二欄、問卷卡單／二欄 | 側欄改為 offcanvas |
| ≥ 992px | 完整水平導覽、雙欄精選區 | 側欄固定於左側（sticky） |
| ≥ 1200px | 四欄捷徑卡、問卷卡三欄 | 儀表板統計卡四欄 |
| 最大 | 內容寬度上限 1440px，兩側自動留白 | 同左 |

---

## 11. 移除的檔案

| 檔案 | 原因 |
| --- | --- |
| `css/css.css` | 已由 Bootstrap + `assets/css/theme.css` 完全取代，且無任何頁面引用 |
| `js/js.js` | 內含唯一函式 `lo()` 全站未被呼叫，其餘為註解掉的舊版 `good()` |
| `js/jquery-1.9.1.min.js` | 由 `vendor/jquery/jquery-3.7.1.min.js` 取代 |

> 以上檔案皆已透過 `git rm` 移除，仍可從 Git 歷史還原。
> `icon/` 目錄下的原始圖片**保留未刪**，僅不再被引用。

另外，`admin.php` 中未被使用的 `#alerr` 遮罩層與 `<iframe name="back">` 一併清除。

---

## 12. 功能相容性說明

**完全維持不變的部分：**

- 資料庫結構、`api/db.php` 的 `DB` 類別與所有查詢邏輯
- `?do=` 路由機制與「找不到頁面就載入首頁」的 fallback
- Session 登入機制、瀏覽人次累計
- 所有表單的 `action`、`method` 與欄位名稱（`del[]`、`sh[]`、`id[]`、`option[]`、
  `acc`、`pw`、`pw2`、`email`、`title`、`type`、`content`、`vote`、`name`）
- 分頁筆數（前台每頁 5 筆、後台每頁 3 筆）與分頁參數 `p`
- 按讚 / 收回讚、問卷投票、問卷開關、文章顯示／軟刪除的行為
- JavaScript 全域函式名稱（`good()`、`reg()`、`login()`、`search()`、
  `active()`、`more()`、`getPosts()`、`getPost()`）

**輸出面的小幅強化（不改變正常資料的呈現結果）：**

- 標題、帳號、分類、問卷題目等「純文字欄位」輸出時加上 `htmlspecialchars`，
  避免資料含 `<`、`&` 等字元時破版。
- 文章內文維持原樣輸出（不跳脫），以保留既有內容的呈現方式。
- 瀏覽人次查詢加上 `?? 0`，資料列不存在時不會噴 PHP Warning。
- `vote.php` / `result.php` 在 `id` 不存在時顯示友善提示，而非 PHP 錯誤。

---

## 13. 實機驗證結果

以 PHP 內建伺服器（`php -S 127.0.0.1:8019`）搭配本機 MySQL（`db19`）實測：

- **PHP 語法檢查**：`php -l` 掃描全部 PHP 檔案，0 錯誤。
- **HTTP 煙霧測試**：20 個路徑（含前台 11 頁、後台 6 頁、API 2 支）全部回傳 `200`，
  輸出中無 Fatal error / Warning / Notice。
- **靜態資源**：Bootstrap CSS/JS、Bootstrap Icons CSS 與 woff2 字型、jQuery、
  主題 CSS/JS、四個 SVG 素材皆回傳 `200`。
- **瀏覽器實測（Chrome）**：
  - 前台首頁、分類網誌、最新文章、人氣文章、問卷調查、投票結果、登入頁
  - 以 `admin / 1234` 實際登入 → 導向後台，儀表板、帳號管理、文章管理、
    問卷管理、新增文章頁面皆正常
  - Accordion 展開、Modal 燈箱、Switch 開關、分頁、深色模式切換皆正常運作
  - Console 無任何錯誤訊息
  - 以 390px 寬檢視前後台：導覽收合、卡片堆疊、表格橫向捲動皆正常
- 測試期間發現並已修正：人氣排行標題溢出、深色模式下淺底徽章對比不足、
  手機版後台表格被壓縮成單字換行、手機版品牌名稱換行、深色模式主視覺白色波浪過亮。

---

## 14. 後續建議（未執行）

以下屬於**功能面／安全面**的問題，因本次任務要求「既有功能不變」而**刻意未更動**，
但建議後續處理：

1. **SQL Injection**：`api/db.php` 的 `a2s()` 直接把值串進 SQL，未使用 prepared statement。
2. **密碼以明文儲存**：`members.pw` 為明文，且 `api/forgot.php` 會直接把密碼回傳給查詢者。
   建議改用 `password_hash()` / `password_verify()`，忘記密碼改為寄送重設連結。
3. **後台缺少權限檢查**：`admin.php` 未驗證 `$_SESSION['login']`，直接輸入網址即可進入後台。
4. **`api/get_posts.php` 未過濾 `del` / `sh`**：分類網誌會列出已隱藏或已軟刪除的文章
   （此為改版前既有行為，本次未變更）。
5. **`db19.sql` 落後於程式碼**：匯出檔中的 `news` 資料表缺少 `del` 欄位、`que` 資料表缺少
   `sh` 欄位，以此檔重建資料庫會導致最新文章與問卷開關功能報錯。建議補上：

   ```sql
   ALTER TABLE `news` ADD `del` INT(1) UNSIGNED NOT NULL DEFAULT 0;
   ALTER TABLE `que`  ADD `sh`  INT(1) UNSIGNED NOT NULL DEFAULT 0;
   ```

6. **文章內文未跳脫**：若未來開放一般會員投稿，需改為跳脫輸出或導入 HTML 白名單過濾。
