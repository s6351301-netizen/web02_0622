<?php
/**
 * 共用頁首版型（前台 / 後台共用）
 * ------------------------------------------------------------------
 * 使用前請先定義：
 *   $HP_AREA  'front' | 'admin'
 *   $do       目前頁面代碼
 *   $HP_PAGE  ['label'=>..,'icon'=>..,'title'=>..]
 */

$HP_AREA = $HP_AREA ?? 'front';
$HP_PAGE = $HP_PAGE ?? ['label' => '首頁', 'icon' => 'bi-house-heart', 'title' => '健康促進網'];
$hpIsAdmin = ($HP_AREA === 'admin');
$hpUser = $_SESSION['login'] ?? null;

/* 瀏覽人次（缺資料時以 0 顯示，避免版面出錯） */
$hpTodayRow    = $Total->find(['date' => date('Y-m-d')]);
$hpTodayViews  = $hpTodayRow['total'] ?? 0;
$hpTotalRow    = $Total->q("select sum(`total`) as 'sum' from `total`");
$hpTotalViews  = $hpTotalRow[0]['sum'] ?? 0;

$hpDocTitle = ($hpIsAdmin ? '後台管理' : $HP_PAGE['label']) . '｜健康促進網';
?>
<!DOCTYPE html>
<html lang="zh-Hant" data-bs-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="description" content="健康促進網社群平台－提供健康新知、菸害防制、癌症防治與慢性病防治等衛教資訊，並開放民眾投稿、按讚與參與問卷調查。">
    <meta name="theme-color" content="#0d9488">
    <meta name="color-scheme" content="light dark">
    <title><?= e($hpDocTitle) ?></title>

    <link rel="icon" href="./assets/img/favicon.svg" type="image/svg+xml">
    <link rel="apple-touch-icon" href="./assets/img/logo-mark.svg">

    <link rel="stylesheet" href="./vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="./vendor/bootstrap-icons/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./assets/css/theme.css">

    <script>
        /* 先套用主題偏好，避免畫面閃爍 */
        (function () {
            try {
                var t = localStorage.getItem('hp-theme') ||
                    (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
                document.documentElement.setAttribute('data-bs-theme', t);
            } catch (e) { /* 忽略 */ }
        })();
    </script>

    <script src="./vendor/jquery/jquery-3.7.1.min.js"></script>
    <script src="./vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>
    <script src="./assets/js/app.js" defer></script>
</head>

<body>
    <a class="hp-skip-link" href="#hp-main">跳至主要內容</a>

    <header>
        <!-- 資訊列 -->
        <div class="hp-topbar">
            <div class="hp-shell d-flex flex-wrap align-items-center justify-content-between gap-2 py-1">
                <div class="d-flex flex-wrap align-items-center gap-2">
                    <span class="hp-topbar-item">
                        <i class="bi bi-calendar3"></i>
                        <time datetime="<?= date('Y-m-d') ?>"><?= date('Y/m/d') ?> <?= hp_weekday() ?></time>
                    </span>
                    <span class="vr d-none d-sm-inline"></span>
                    <span class="hp-topbar-item d-none d-sm-inline-flex">
                        <i class="bi bi-eye"></i> 今日瀏覽 <strong><?= (int) $hpTodayViews ?></strong>
                    </span>
                    <span class="vr d-none d-sm-inline"></span>
                    <span class="hp-topbar-item d-none d-sm-inline-flex">
                        <i class="bi bi-graph-up"></i> 累積瀏覽 <strong><?= (int) $hpTotalViews ?></strong>
                    </span>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <a class="hp-topbar-item" href="mailto:health@test.labor.gov.tw">
                        <i class="bi bi-envelope"></i><span class="d-none d-md-inline">health@test.labor.gov.tw</span>
                    </a>
                    <a class="hp-topbar-item" href="index.php">
                        <i class="bi bi-house-door"></i>回首頁
                    </a>
                </div>
            </div>
        </div>

        <!-- 主導覽列 -->
        <nav class="navbar navbar-expand-lg hp-navbar sticky-top" aria-label="主要導覽">
            <div class="hp-shell d-flex align-items-center w-100 gap-2">

                <?php if ($hpIsAdmin): ?>
                    <button class="btn btn-outline-secondary border-0 d-lg-none px-2" type="button"
                            data-bs-toggle="offcanvas" data-bs-target="#hpAdminNav" aria-controls="hpAdminNav"
                            aria-label="開啟管理選單">
                        <i class="bi bi-list fs-4"></i>
                    </button>
                <?php endif; ?>

                <a class="hp-brand me-auto" href="<?= $hpIsAdmin ? 'admin.php' : 'index.php' ?>">
                    <img class="hp-brand__mark" src="./assets/img/logo-mark.svg" alt="健康促進網標誌" width="42" height="42">
                    <span class="hp-brand__text">
                        <span class="hp-brand__name">健康促進網</span>
                        <span class="hp-brand__tag d-none d-sm-block">Health Promotion Network</span>
                    </span>
                    <?php if ($hpIsAdmin): ?>
                        <span class="hp-brand__badge">後台</span>
                    <?php endif; ?>
                </a>

                <?php if (!$hpIsAdmin): ?>
                    <button class="navbar-toggler border-0 order-lg-last" type="button" data-bs-toggle="collapse"
                            data-bs-target="#hpMainNav" aria-controls="hpMainNav" aria-expanded="false"
                            aria-label="開啟主選單">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse flex-lg-grow-0" id="hpMainNav">
                        <ul class="navbar-nav hp-nav my-2 my-lg-0">
                            <?php foreach ($HP_FRONT_NAV as $key => $item): ?>
                                <li class="nav-item">
                                    <a class="nav-link<?= hp_is($do, $key) ?>" href="?do=<?= e($key) ?>"
                                       <?= $do === $key ? 'aria-current="page"' : '' ?>>
                                        <i class="bi <?= e($item['icon']) ?> d-lg-none"></i><?= e($item['label']) ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="d-flex align-items-center gap-2 ms-lg-2">
                    <button class="hp-theme-toggle" type="button" data-hp-theme-toggle aria-label="切換色彩模式">
                        <i class="bi bi-moon-stars-fill" data-hp-theme-icon></i>
                    </button>

                    <?php if ($hpUser !== null): ?>
                        <div class="dropdown">
                            <button class="btn btn-link p-0 border-0 d-flex align-items-center gap-2 text-decoration-none"
                                    type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="hp-avatar"><?= e(hp_initial($hpUser)) ?></span>
                                <span class="d-none d-md-inline fw-semibold text-body"><?= e($hpUser) ?></span>
                                <i class="bi bi-chevron-down small text-body-secondary"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li class="px-3 py-2">
                                    <div class="fw-bold text-body"><?= e($hpUser) ?></div>
                                    <div class="small hp-text-muted">
                                        <?= $hpUser === 'admin' ? '系統管理員' : '一般會員' ?>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <?php if ($hpUser === 'admin'): ?>
                                    <li>
                                        <a class="dropdown-item" href="admin.php">
                                            <i class="bi bi-sliders me-2"></i>後台管理
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <li>
                                    <a class="dropdown-item" href="index.php">
                                        <i class="bi bi-house-door me-2"></i>前台首頁
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-danger" href="./api/logout.php">
                                        <i class="bi bi-box-arrow-right me-2"></i>登出
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a class="btn btn-primary btn-sm px-3" href="index.php?do=login">
                            <i class="bi bi-box-arrow-in-right me-1"></i>會員登入
                        </a>
                        <a class="btn btn-outline-primary btn-sm px-3 d-none d-sm-inline-block" href="index.php?do=reg">
                            註冊
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>

        <!-- 公告跑馬燈 -->
        <div class="hp-marquee py-1">
            <div class="hp-shell">
                <div class="d-flex align-items-center gap-2">
                    <span class="badge text-bg-success flex-shrink-0">
                        <i class="bi bi-megaphone-fill me-1"></i>公告
                    </span>
                    <div class="hp-marquee__track">
                        請民眾踴躍投稿電子報，讓電子報成為大家相互交流、分享的園地！詳見最新文章
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main id="hp-main" class="hp-main">
        <div class="hp-shell">
