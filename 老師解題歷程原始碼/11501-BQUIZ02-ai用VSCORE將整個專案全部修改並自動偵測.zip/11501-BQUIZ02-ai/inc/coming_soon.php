<?php
/**
 * 尚未實作之功能的共用畫面
 * 需要外部提供：$HP_PAGE、$HP_SOON_DESC（選填）、$HP_SOON_LINKS（選填）
 */
$HP_SOON_DESC  = $HP_SOON_DESC ?? '此功能正在開發中，完成後即會在這裡提供操作介面。';
$HP_SOON_LINKS = $HP_SOON_LINKS ?? [];
?>
<div class="card">
    <div class="card-body p-4 p-lg-5 text-center">
        <span class="hp-quick__icon mx-auto" style="width:72px;height:72px;font-size:2rem">
            <i class="bi <?= e($HP_PAGE['icon']) ?>"></i>
        </span>

        <h2 class="h4 mt-3 mb-2"><?= e($HP_PAGE['title']) ?>　功能籌備中</h2>
        <p class="hp-text-muted mb-4" style="max-width:52ch;margin-inline:auto;line-height:2">
            <?= e($HP_SOON_DESC) ?>
        </p>

        <?php if (!empty($HP_SOON_LINKS)): ?>
            <div class="d-flex flex-wrap justify-content-center gap-2">
                <?php foreach ($HP_SOON_LINKS as $link): ?>
                    <a class="btn <?= e($link['class'] ?? 'btn-soft') ?>" href="<?= e($link['href']) ?>">
                        <i class="bi <?= e($link['icon']) ?> me-1"></i><?= e($link['label']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
