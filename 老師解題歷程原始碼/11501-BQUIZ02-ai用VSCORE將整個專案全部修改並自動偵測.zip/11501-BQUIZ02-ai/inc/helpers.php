<?php
/**
 * 共用輔助函式與導覽設定
 * ------------------------------------------------------------------
 * 由 index.php（前台）與 admin.php（後台）於輸出前載入。
 */

if (!function_exists('e')) {
    /** 輸出跳脫，避免 HTML 破版與 XSS */
    function e($value)
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('hp_is')) {
    /** 判斷目前頁面，回傳 active class */
    function hp_is($current, $key, $class = ' active')
    {
        return $current === $key ? $class : '';
    }
}

if (!function_exists('hp_initial')) {
    /** 取帳號首字作為頭像文字 */
    function hp_initial($name)
    {
        return mb_substr((string) $name, 0, 1, 'UTF-8');
    }
}

if (!function_exists('hp_weekday')) {
    /** 中文星期 */
    function hp_weekday($timestamp = null)
    {
        $week = ['日', '一', '二', '三', '四', '五', '六'];
        return '星期' . $week[(int) date('w', $timestamp ?? time())];
    }
}

/** 前台主選單 */
$HP_FRONT_NAV = [
    'main' => ['label' => '首頁',     'icon' => 'bi-house-heart',       'title' => '健康生活 從今天開始'],
    'po'   => ['label' => '分類網誌', 'icon' => 'bi-journals',          'title' => '分類網誌'],
    'news' => ['label' => '最新文章', 'icon' => 'bi-newspaper',         'title' => '最新文章'],
    'pop'  => ['label' => '人氣文章', 'icon' => 'bi-fire',              'title' => '人氣文章'],
    'know' => ['label' => '講座訊息', 'icon' => 'bi-calendar2-event',   'title' => '講座訊息'],
    'que'  => ['label' => '問卷調查', 'icon' => 'bi-clipboard2-pulse',  'title' => '問卷調查'],
];

/** 前台非選單頁面的標題設定 */
$HP_FRONT_EXTRA = [
    'login'  => ['label' => '會員登入', 'icon' => 'bi-box-arrow-in-right', 'title' => '會員登入'],
    'reg'    => ['label' => '會員註冊', 'icon' => 'bi-person-plus',        'title' => '會員註冊'],
    'forgot' => ['label' => '忘記密碼', 'icon' => 'bi-key',                'title' => '忘記密碼'],
    'vote'   => ['label' => '參與投票', 'icon' => 'bi-check2-square',      'title' => '參與投票'],
    'result' => ['label' => '投票結果', 'icon' => 'bi-bar-chart-line',     'title' => '投票結果'],
];

/** 後台主選單 */
$HP_ADMIN_NAV = [
    'main' => ['label' => '管理首頁',     'icon' => 'bi-speedometer2',      'title' => '管理首頁'],
    'acc'  => ['label' => '帳號管理',     'icon' => 'bi-people',            'title' => '帳號管理'],
    'po'   => ['label' => '分類網誌',     'icon' => 'bi-journals',          'title' => '分類網誌'],
    'news' => ['label' => '最新文章管理', 'icon' => 'bi-newspaper',         'title' => '最新文章管理'],
    'know' => ['label' => '講座訊息',     'icon' => 'bi-calendar2-event',   'title' => '講座訊息'],
    'que'  => ['label' => '問卷管理',     'icon' => 'bi-clipboard2-pulse',  'title' => '問卷管理'],
];

/** 後台非選單頁面 */
$HP_ADMIN_EXTRA = [
    'add_news' => ['label' => '新增文章', 'icon' => 'bi-file-earmark-plus', 'title' => '新增文章'],
];
