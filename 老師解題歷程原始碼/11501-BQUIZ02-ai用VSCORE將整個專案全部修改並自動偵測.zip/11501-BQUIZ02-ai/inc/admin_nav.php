<?php
/**
 * 後台側邊選單內容（桌機側欄與行動版 offcanvas 共用）
 * 需要外部提供：$do、$HP_ADMIN_NAV
 */
?>
<div class="hp-sidebar__label">管理功能</div>
<nav class="nav flex-column" aria-label="後台功能選單">
    <?php foreach ($HP_ADMIN_NAV as $key => $item): ?>
        <a class="nav-link<?= hp_is($do, $key) ?>" href="?do=<?= e($key) ?>"
           <?= $do === $key ? 'aria-current="page"' : '' ?>>
            <i class="bi <?= e($item['icon']) ?>"></i>
            <span><?= e($item['label']) ?></span>
        </a>
    <?php endforeach; ?>
</nav>

<hr class="hp-divider-soft my-2">

<div class="hp-sidebar__label">快速操作</div>
<nav class="nav flex-column" aria-label="快速操作">
    <a class="nav-link<?= hp_is($do, 'add_news') ?>" href="?do=add_news">
        <i class="bi bi-file-earmark-plus"></i><span>新增文章</span>
    </a>
    <a class="nav-link" href="index.php" target="_blank" rel="noopener">
        <i class="bi bi-box-arrow-up-right"></i><span>檢視前台</span>
    </a>
    <a class="nav-link text-danger" href="./api/logout.php">
        <i class="bi bi-box-arrow-right"></i><span>登出</span>
    </a>
</nav>
