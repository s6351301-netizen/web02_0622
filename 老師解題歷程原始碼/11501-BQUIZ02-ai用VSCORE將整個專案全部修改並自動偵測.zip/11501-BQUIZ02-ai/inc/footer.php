<?php
/**
 * 共用頁尾版型（前台 / 後台共用）
 */
$hpIsAdmin = $hpIsAdmin ?? false;
?>
        </div><!-- /.hp-shell -->
    </main>

    <footer class="hp-footer pt-5 pb-3">
        <div class="hp-shell">
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="hp-footer__brand mb-3">
                        <img src="./assets/img/logo-mark.svg" alt="健康促進網標誌" width="40" height="40">
                        <div>
                            <div class="hp-footer__title">健康促進網</div>
                            <div class="small" style="letter-spacing:.18em;opacity:.65">HEALTH PROMOTION NETWORK</div>
                        </div>
                    </div>
                    <p class="mb-3" style="line-height:1.9">
                        推廣健康生活型態，提供健康新知、菸害防制、癌症防治與慢性病防治等衛教資訊，
                        邀請您一起把健康帶進日常。
                    </p>
                    <div class="d-flex gap-2">
                        <a class="btn btn-sm btn-outline-light rounded-pill px-3" href="index.php?do=news">
                            <i class="bi bi-newspaper me-1"></i>最新文章
                        </a>
                        <a class="btn btn-sm btn-outline-light rounded-pill px-3" href="index.php?do=que">
                            <i class="bi bi-clipboard2-pulse me-1"></i>問卷調查
                        </a>
                    </div>
                </div>

                <div class="col-6 col-lg-2">
                    <h3 class="h6 fw-bold mb-3">網站導覽</h3>
                    <ul class="hp-footer__list">
                        <li><a href="index.php?do=main">首頁</a></li>
                        <li><a href="index.php?do=po">分類網誌</a></li>
                        <li><a href="index.php?do=news">最新文章</a></li>
                        <li><a href="index.php?do=pop">人氣文章</a></li>
                    </ul>
                </div>

                <div class="col-6 col-lg-2">
                    <h3 class="h6 fw-bold mb-3">會員服務</h3>
                    <ul class="hp-footer__list">
                        <li><a href="index.php?do=login">會員登入</a></li>
                        <li><a href="index.php?do=reg">會員註冊</a></li>
                        <li><a href="index.php?do=forgot">忘記密碼</a></li>
                        <li><a href="index.php?do=know">講座訊息</a></li>
                    </ul>
                </div>

                <div class="col-lg-4">
                    <h3 class="h6 fw-bold mb-3">聯絡我們</h3>
                    <ul class="hp-footer__list">
                        <li class="d-flex gap-2">
                            <i class="bi bi-envelope-fill mt-1"></i>
                            <a href="mailto:health@test.labor.gov.tw">health@test.labor.gov.tw</a>
                        </li>
                        <li class="d-flex gap-2">
                            <i class="bi bi-clock-fill mt-1"></i>
                            <span>服務時間：週一至週五 08:30 - 17:30</span>
                        </li>
                        <li class="d-flex gap-2">
                            <i class="bi bi-universal-access-circle mt-1"></i>
                            <span>本網站支援鍵盤操作、深色模式與行動裝置瀏覽</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="hp-footer__bottom mt-4 pt-3 d-flex flex-wrap justify-content-between gap-2">
                <span>Copyright &copy; <?= date('Y') ?> 健康促進網社群平台 All Rights Reserved.</span>
                <span>本網站採用響應式設計，支援手機、平板與桌機瀏覽。</span>
            </div>
        </div>
    </footer>

    <button class="hp-to-top" type="button" aria-label="回到頁面頂端">
        <i class="bi bi-arrow-up"></i>
    </button>

    <div class="toast-container position-fixed bottom-0 end-0 p-3" id="hpToastHost" style="z-index:1090"></div>
</body>

</html>
