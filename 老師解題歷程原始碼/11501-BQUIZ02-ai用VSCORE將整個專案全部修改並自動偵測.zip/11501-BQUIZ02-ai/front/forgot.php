<?php
/**
 * 忘記密碼：以電子信箱查詢
 */
?>
<div class="hp-auth">
    <div class="hp-auth__card">
        <div class="hp-auth__head">
            <i class="bi bi-key"></i>
            <h1 class="h5 text-white mt-2 mb-1">忘記密碼</h1>
            <p class="mb-0 small" style="opacity:.85">輸入註冊時使用的電子信箱以查詢</p>
        </div>

        <div class="hp-auth__body">
            <form onsubmit="event.preventDefault(); search();" novalidate>
                <div class="mb-3">
                    <label class="form-label" for="email">電子信箱</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" class="form-control" name="email" id="email"
                               autocomplete="email" placeholder="name@example.com" required>
                    </div>
                </div>

                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="bi bi-search me-1"></i>尋找
                    </button>
                </div>
            </form>

            <div id="result" class="alert alert-brand mt-3 mb-0 d-none" role="status"></div>

            <hr class="hp-divider-soft my-4">

            <div class="d-flex justify-content-between small">
                <a href="?do=login"><i class="bi bi-box-arrow-in-right me-1"></i>返回登入</a>
                <a href="?do=reg"><i class="bi bi-person-plus me-1"></i>註冊新帳號</a>
            </div>
        </div>
    </div>
</div>

<script>
    function search() {
        var email = $("#email").val();
        if (!email) {
            if (window.hpToast) { window.hpToast("請輸入電子信箱", "warning"); } else { alert("請輸入電子信箱"); }
            return;
        }
        $.get("./api/forgot.php", { email: email }, function (result) {
            $("#result").removeClass("d-none")
                .html('<i class="bi bi-info-circle-fill me-1"></i>' + $("<div>").text(result).html());
        });
    }
</script>
