<?php
/**
 * 最新文章：分頁列出已開放的文章，可展開全文並按讚
 */
$total  = $News->count(['sh' => 1, 'del' => 0]);
$div    = 5;
$pages  = ceil($total / $div);
$now    = (int) ($_GET['p'] ?? 1);
$start  = ($now - 1) * $div;
$posts  = $News->all(['sh' => 1, 'del' => 0], " limit $start,$div");
$hpUser = $_SESSION['login'] ?? null;
?>

<div class="card">
    <div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2">
        <span><i class="bi bi-newspaper text-primary me-2"></i>文章列表</span>
        <span class="badge text-bg-brand">共 <?= (int) $total ?> 篇．第 <?= $now ?> / <?= max(1, (int) $pages) ?> 頁</span>
    </div>

    <div class="card-body p-3 p-md-4">
        <?php if (empty($posts)): ?>
            <div class="hp-empty">
                <i class="bi bi-inbox"></i>
                目前沒有可顯示的文章
            </div>
        <?php else: ?>
            <div class="accordion accordion-flush" id="hpNewsList">
                <?php foreach ($posts as $idx => $post): ?>
                    <?php
                    $pid   = (int) $post['id'];
                    $liked = $hpUser !== null
                        && $Log->count(['user' => $hpUser, 'news' => $pid]) > 0;
                    ?>
                    <article class="accordion-item">
                        <h2 class="accordion-header" id="newsHead<?= $pid ?>">
                            <button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#newsBody<?= $pid ?>"
                                    aria-expanded="false" aria-controls="newsBody<?= $pid ?>">
                                <span class="w-100 min-w-0 pe-2">
                                    <span class="d-flex align-items-center gap-2">
                                        <span class="badge text-bg-brand flex-shrink-0"><?= e($post['type']) ?></span>
                                        <span class="fw-bold text-truncate"><?= e($post['title']) ?></span>
                                    </span>
                                    <span class="d-block small hp-text-muted text-truncate mt-1">
                                        <?= e(mb_substr($post['content'], 0, 40)) ?>…
                                    </span>
                                </span>
                            </button>
                        </h2>
                        <div id="newsBody<?= $pid ?>" class="accordion-collapse collapse"
                             aria-labelledby="newsHead<?= $pid ?>" data-bs-parent="#hpNewsList">
                            <div class="accordion-body">
                                <div class="hp-prose hp-prose--boxed mb-3"><?= $post['content'] ?></div>
                                <footer class="d-flex flex-wrap align-items-center gap-2">
                                    <span class="badge text-bg-brand">
                                        <i class="bi bi-hand-thumbs-up me-1"></i><?= (int) $post['good'] ?> 人說讚
                                    </span>
                                    <?php if ($hpUser !== null): ?>
                                        <button type="button"
                                                class="hp-like<?= $liked ? ' is-liked' : '' ?>"
                                                onclick="good(<?= $pid ?>)">
                                            <i class="bi <?= $liked ? 'bi-heart-fill' : 'bi-heart' ?>"></i>
                                            <?= $liked ? '收回讚' : '讚' ?>
                                        </button>
                                    <?php else: ?>
                                        <a class="hp-like" href="?do=login">
                                            <i class="bi bi-box-arrow-in-right"></i>登入後可按讚
                                        </a>
                                    <?php endif; ?>
                                </footer>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php if ($pages > 1): ?>
        <div class="card-footer bg-transparent d-flex justify-content-center py-3">
            <nav aria-label="文章分頁">
                <ul class="pagination mb-0">
                    <li class="page-item<?= $now <= 1 ? ' disabled' : '' ?>">
                        <a class="page-link" href="?do=news&p=<?= $now - 1 ?>" aria-label="上一頁">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                        <li class="page-item<?= $i === $now ? ' active' : '' ?>">
                            <a class="page-link" href="?do=news&p=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item<?= $now >= $pages ? ' disabled' : '' ?>">
                        <a class="page-link" href="?do=news&p=<?= $now + 1 ?>" aria-label="下一頁">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<script>
    function good(id) {
        $.post("./api/good.php", { id: id }, function () {
            location.reload();
        });
    }
</script>
