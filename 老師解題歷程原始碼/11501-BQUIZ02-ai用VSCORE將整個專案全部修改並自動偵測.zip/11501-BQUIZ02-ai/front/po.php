<?php
/**
 * 分類網誌：左側選擇分類，右側以 AJAX 載入文章列表 / 內容
 */
$hpTypes = [
    ['name' => '健康新知',   'icon' => 'bi-heart-pulse'],
    ['name' => '菸害防制',   'icon' => 'bi-slash-circle'],
    ['name' => '癌症防治',   'icon' => 'bi-shield-plus'],
    ['name' => '慢性病防治', 'icon' => 'bi-capsule'],
];
?>

<div class="row g-4">
    <!-- 分類選單 -->
    <div class="col-lg-3">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-tags text-primary me-2"></i>文章分類
            </div>
            <nav class="list-group list-group-flush" aria-label="文章分類">
                <?php foreach ($hpTypes as $i => $type): ?>
                    <button type="button"
                            class="list-group-item list-group-item-action type-item d-flex align-items-center gap-2<?= $i === 0 ? ' active' : '' ?>"
                            data-type="<?= e($type['name']) ?>">
                        <i class="bi <?= e($type['icon']) ?>"></i>
                        <span><?= e($type['name']) ?></span>
                        <i class="bi bi-chevron-right ms-auto small"></i>
                    </button>
                <?php endforeach; ?>
            </nav>
        </div>

        <aside class="alert alert-brand mt-3 mb-0 small" role="note">
            <i class="bi bi-lightbulb me-1"></i>
            點選左側分類即可切換主題，再點選標題閱讀全文。
        </aside>
    </div>

    <!-- 文章列表 / 內容 -->
    <div class="col-lg-9">
        <div class="card">
            <div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2">
                <span>
                    <i class="bi bi-journal-text text-primary me-2"></i>
                    <span class="nav-item-name">健康新知</span>
                </span>
                <button type="button" class="btn btn-sm btn-soft d-none" id="backToList">
                    <i class="bi bi-arrow-left me-1"></i>返回列表
                </button>
            </div>

            <div class="card-body p-0">
                <div class="post-list list-group list-group-flush"></div>
                <article class="post-content p-4 d-none"></article>
            </div>
        </div>
    </div>
</div>

<script>
    (function () {
        var $list = $(".post-list");
        var $content = $(".post-content");
        var $back = $("#backToList");

        function loading() {
            $list.html('<div class="hp-empty"><div class="spinner-border text-primary" role="status">' +
                '<span class="visually-hidden">載入中</span></div></div>').removeClass("d-none");
            $content.addClass("d-none");
            $back.addClass("d-none");
        }

        window.getPosts = function (type) {
            loading();
            $.get("./api/get_posts.php", { type: type }, function (list) {
                $list.html(list.trim() ||
                    '<div class="hp-empty"><i class="bi bi-inbox"></i>此分類目前沒有文章</div>');
            });
        };

        window.getPost = function (id) {
            $.get("./api/get_post.php", { id: id }, function (post) {
                $content.html(post);
                $list.addClass("d-none");
                $content.removeClass("d-none");
                $back.removeClass("d-none");
            });
        };

        $back.on("click", function () {
            $content.addClass("d-none");
            $list.removeClass("d-none");
            $back.addClass("d-none");
        });

        $(".type-item").on("click", function () {
            var type = $(this).data("type");
            $(".type-item").removeClass("active");
            $(this).addClass("active");
            $(".nav-item-name").text(type);
            getPosts(type);
        });

        // 初始載入第一個分類
        getPosts($(".type-item").eq(0).data("type"));
    })();
</script>
