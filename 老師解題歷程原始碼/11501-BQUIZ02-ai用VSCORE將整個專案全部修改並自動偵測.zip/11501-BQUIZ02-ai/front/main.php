<?php
/**
 * 前台首頁：主視覺 + 功能捷徑 + 健康專欄（四大主題）+ 最新／人氣文章
 */
$hpNewsCount = $News->count(['sh' => 1, 'del' => 0]);
$hpMemCount  = $Mem->count();
$hpQueCount  = $Que->count(['main_id' => 0]);
$hpLatest    = $News->all(['sh' => 1, 'del' => 0], " order by `id` desc limit 4");
$hpHot       = $News->all(['sh' => 1, 'del' => 0], " order by `good` desc limit 4");

$hpTopics = [
    'health' => ['title' => '健康新知', 'icon' => 'bi-heart-pulse',   'desc' => '運動與體能促進'],
    'smoke'  => ['title' => '菸害防制', 'icon' => 'bi-slash-circle',  'desc' => '菸害防制法規'],
    'cancer' => ['title' => '癌症防治', 'icon' => 'bi-shield-plus',   'desc' => '降低罹癌風險'],
    'chron'  => ['title' => '慢性病防治', 'icon' => 'bi-capsule',     'desc' => '日常保健觀念'],
];
?>

<!-- ===================== 主視覺 ===================== -->
<section class="hp-hero mb-4" aria-labelledby="hpHeroTitle">
    <img class="hp-hero__bg" src="./assets/img/banner.svg" alt="" aria-hidden="true">
    <div class="hp-hero__inner">
        <div class="row align-items-center g-4">
            <div class="col-lg-7">
                <span class="hp-hero__eyebrow mb-3">
                    <i class="bi bi-stars"></i>健康促進網社群平台
                </span>
                <h1 class="hp-hero__title mb-3" id="hpHeroTitle">
                    健康生活<br class="d-none d-sm-block">從今天的每一步開始
                </h1>
                <p class="hp-hero__lead mb-4">
                    每天運動 15 分鐘，就能減少 14% 總死亡風險。
                    這裡集結健康新知、菸害防制、癌症防治與慢性病防治資訊，
                    歡迎加入社群，分享您的健康心得。
                </p>
                <div class="d-flex flex-wrap gap-2">
                    <a class="btn btn-light btn-lg fw-bold px-4 hp-hero__btn" href="?do=news">
                        <i class="bi bi-newspaper me-1"></i>閱讀最新文章
                    </a>
                    <a class="btn btn-outline-light btn-lg px-4" href="?do=que">
                        <i class="bi bi-clipboard2-pulse me-1"></i>參與問卷調查
                    </a>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="hp-hero__stats justify-content-lg-end">
                    <div class="hp-hero__stat">
                        <b><?= (int) $hpNewsCount ?></b><span>篇健康文章</span>
                    </div>
                    <div class="hp-hero__stat">
                        <b><?= (int) $hpMemCount ?></b><span>位社群會員</span>
                    </div>
                    <div class="hp-hero__stat">
                        <b><?= (int) $hpQueCount ?></b><span>份問卷調查</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ===================== 功能捷徑 ===================== -->
<section class="mb-4" aria-label="功能捷徑">
    <div class="row g-3">
        <div class="col-6 col-lg-3">
            <a class="hp-quick" href="?do=po">
                <span class="hp-quick__icon"><i class="bi bi-journals"></i></span>
                <div class="hp-quick__title">分類網誌</div>
                <p class="hp-quick__desc">依主題分類瀏覽衛教文章</p>
            </a>
        </div>
        <div class="col-6 col-lg-3">
            <a class="hp-quick" href="?do=news">
                <span class="hp-quick__icon"><i class="bi bi-newspaper"></i></span>
                <div class="hp-quick__title">最新文章</div>
                <p class="hp-quick__desc">掌握最新發布的健康資訊</p>
            </a>
        </div>
        <div class="col-6 col-lg-3">
            <a class="hp-quick" href="?do=pop">
                <span class="hp-quick__icon"><i class="bi bi-fire"></i></span>
                <div class="hp-quick__title">人氣文章</div>
                <p class="hp-quick__desc">看看大家最推薦哪些內容</p>
            </a>
        </div>
        <div class="col-6 col-lg-3">
            <a class="hp-quick" href="?do=que">
                <span class="hp-quick__icon"><i class="bi bi-clipboard2-pulse"></i></span>
                <div class="hp-quick__title">問卷調查</div>
                <p class="hp-quick__desc">表達您的看法並查看結果</p>
            </a>
        </div>
    </div>
</section>

<!-- ===================== 最新 / 人氣文章 ===================== -->
<section class="mb-4" aria-label="文章精選">
    <div class="row g-4">
        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <span><i class="bi bi-clock-history text-primary me-2"></i>最新文章</span>
                    <a class="btn btn-sm btn-soft" href="?do=news">更多<i class="bi bi-chevron-right ms-1"></i></a>
                </div>
                <ul class="list-group list-group-flush">
                    <?php if (empty($hpLatest)): ?>
                        <li class="list-group-item hp-empty"><i class="bi bi-inbox"></i>目前尚無文章</li>
                    <?php else: ?>
                        <?php foreach ($hpLatest as $row): ?>
                            <li class="list-group-item d-flex align-items-start gap-3">
                                <i class="bi bi-dot fs-4 text-primary lh-1"></i>
                                <div class="flex-grow-1 min-w-0">
                                    <a class="fw-semibold d-block text-body text-truncate" href="?do=news"
                                       title="<?= e($row['title']) ?>"><?= e($row['title']) ?></a>
                                    <small class="hp-text-muted"><?= e($row['type']) ?></small>
                                </div>
                                <span class="badge text-bg-brand flex-shrink-0">
                                    <i class="bi bi-hand-thumbs-up me-1"></i><?= (int) $row['good'] ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <span><i class="bi bi-fire text-danger me-2"></i>人氣排行</span>
                    <a class="btn btn-sm btn-soft" href="?do=pop">更多<i class="bi bi-chevron-right ms-1"></i></a>
                </div>
                <ul class="list-group list-group-flush">
                    <?php if (empty($hpHot)): ?>
                        <li class="list-group-item hp-empty"><i class="bi bi-inbox"></i>目前尚無文章</li>
                    <?php else: ?>
                        <?php foreach ($hpHot as $i => $row): ?>
                            <li class="list-group-item d-flex align-items-center gap-3">
                                <span class="hp-rank hp-rank--<?= $i + 1 ?>"><?= $i + 1 ?></span>
                                <div class="flex-grow-1 min-w-0">
                                    <a class="fw-semibold d-block text-body text-truncate" href="?do=pop"
                                       title="<?= e($row['title']) ?>"><?= e($row['title']) ?></a>
                                    <small class="hp-text-muted"><?= e($row['type']) ?></small>
                                </div>
                                <span class="badge text-bg-brand flex-shrink-0">
                                    <i class="bi bi-hand-thumbs-up me-1"></i><?= (int) $row['good'] ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- ===================== 健康專欄（四大主題） ===================== -->
<section aria-labelledby="hpTopicTitle">
    <h2 class="hp-section-title" id="hpTopicTitle">健康專欄</h2>

    <div class="card">
        <div class="card-header p-0 border-bottom-0">
            <ul class="nav nav-pills gap-2 p-3 flex-nowrap overflow-auto" id="hpTopicTab" role="tablist">
                <?php $first = true; foreach ($hpTopics as $key => $topic): ?>
                    <li class="nav-item flex-shrink-0" role="presentation">
                        <button class="nav-link<?= $first ? ' active' : '' ?>" id="tab-<?= e($key) ?>"
                                data-bs-toggle="pill" data-bs-target="#pane-<?= e($key) ?>" type="button"
                                role="tab" aria-controls="pane-<?= e($key) ?>"
                                aria-selected="<?= $first ? 'true' : 'false' ?>">
                            <i class="bi <?= e($topic['icon']) ?> me-1"></i><?= e($topic['title']) ?>
                        </button>
                    </li>
                <?php $first = false; endforeach; ?>
            </ul>
        </div>

        <div class="card-body pt-0">
            <div class="tab-content" id="hpTopicContent">

                <!-- 健康新知 -->
                <article class="tab-pane fade show active" id="pane-health" role="tabpanel" aria-labelledby="tab-health" tabindex="0">
                    <header class="border-bottom pb-3 mb-3">
                        <h3 class="h5 mb-1">缺乏運動已成為影響全球死亡率的第四大危險因子</h3>
                        <p class="small hp-text-muted mb-0">
                            <i class="bi bi-building me-1"></i>行政院衛生署國民健康局
                            <span class="mx-2">|</span>
                            <i class="bi bi-calendar3 me-1"></i><time datetime="2012-10-07">2012 / 10 / 07</time>
                        </p>
                    </header>
                    <pre class="hp-prose">
國人無規律運動之比率高達72.2%

世界衛生組織指出運動不足已成全球第四大致死因素，每年有6%的死亡率與運動不足有關，僅次於高血壓（13％）、菸品使用（9％）及高血糖（6％）之後，有超過200萬死亡人數可歸因於靜態生活。世界上約60-85％的成人過著靜態生活，三分之二的兒童運動不足，未來都將影響健康並造成公共衛生問題。運動不足除了增加死亡率，還會使心血管疾病、糖尿病、肥胖的風險加倍，並增加大腸癌、高血壓、骨質疏鬆、脂質失調症（lipid disorders）、憂鬱、焦慮的風險。大約21-25％乳癌及大腸癌、27%糖尿病與30％的缺血性心臟病，係因運動不足所造成。許多國家運動不足的人口比率，也正不斷地增加，依據行政院體育委員會2011年運動城巿調查結果顯示，國人無規律運動習慣之比率高達72.2%。
我國十大死因的危險因子皆與運動不足有關，運動的好處很多，可以預防慢性疾病，降低罹患癌症、跌倒的風險等。國家衛生研究院溫啟邦教授利用台灣一個大型的追蹤世代，分析各個不同運動量的健康效益。研究發現，與不運動的人相比，每天運動15分鐘(每週約90分鐘)是可以減少14%總死亡、10%癌症死亡及20%的心血管疾病死亡，延長3年壽命。這些好處不但適用於各個年齡層包括年青人、年老人，也適用於男性與女性，對有心血管疾病風險的人包括吸菸、肥胖者，也一樣有用。
國民健康局鼓勵民眾養成規律運動習慣，對於預防心血管疾病、糖尿病、高血脂以及高血壓等，都有顯著的效益，並可降低罹患癌症的風險，加速代謝脂肪，強化肌肉組織與功能，維持健康體重，提高腦內啡的釋放，降低情緒壓力。一般而言，成人只要每週運動累積達150分鐘、兒童每日運動累積60分鐘，就能有足夠的運動量，建議成人每天運動30分鐘，可分段累積運動量，效果與一次做完一樣。例如上下班(學)通勤時間與中午休息時間分段進行，每次15分鐘分2次或是每次10分鐘分3次完成，只要每天持之以恆，健康體能就會大大地提昇。
許多上班族時常抱怨沒時間或空間運動，國民健康局製作15分鐘「上班族健康操」，不受場地、服裝的限制，每天上、下午各跳15分鐘健康操，可消耗100大卡的熱量，持續1年，約可減少4公斤，不但消耗過多熱量，還能促進身體健康。國民健康局為幫助同仁達到規律運動，運用電腦提示系統，於每天上午9時45分及下午3時45分，電腦螢幕會自動跳出「上班族健康操」畫面，鼓勵同仁暫時放下手邊的工作，隨著音樂一起動一動。
對於沒有運動習的民眾，「健走」也是很好的入門運動，衛生署國民健康局自91年起推動「每日一萬步 健康有保固」，「健走」是既簡單又輕鬆的運動，不需特殊裝備，只要穿著輕便服裝、運動鞋，運用「抬頭挺胸縮小腹、雙手微握放腰部、自然擺動肩放鬆、邁開腳步向前行」健走小口訣，以4公里/小時的速度，日行萬步，只要90分鐘，步行約6公里，就可以消耗約300大卡，走向健康。
國民健康局並介紹運動生活化之小撇步，協助民眾落實生活化的運動。
1. 從日常生活中找出時間來活動，例如：步行買午、晚餐、水果、日用品；步行去用餐；蹓狗。
2. 外出或是上下班(學)不妨多多利用大眾運輸工具，讓自己提早出門提前一站下車，步行至目的地。
3. 可以走樓梯就不要坐電梯，如果一下子沒辦法走這麼多樓梯，步行走上幾層樓後再搭乘電梯，慢慢增加自己的運動量。
4. 多和家人到戶外活動，或騎腳踏車、打球等活動。
5. 假日可以自己動手整理家裡、擦擦地板，也可以增加運動量!或利用掃地、拖地時加大動作幅度，那也是很好的身體活動。
6. 在家裡、辦公室附近找方便的資源運動，包括公園、職場辦的課程、活動。
7. 減少看電視、打電玩等靜態生活的時間。
    民眾對運動如有疑問，可參考國民健康局肥胖防治網-「快樂動」(http://obesity.bhp.gov.tw)，亦可撥打免費市話健康體重管理電話諮詢服務，諮詢專線「0800-367-100（0800-瘦落去-要動動）」，也可利用國民健康局局網首頁或肥胖防治網問題諮詢專區的網路電話撥入功能，向客服人員諮詢關於運動、健康飲食及健康體重管理等相關疑問。</pre>
                </article>

                <!-- 菸害防制 -->
                <article class="tab-pane fade" id="pane-smoke" role="tabpanel" aria-labelledby="tab-smoke" tabindex="0">
                    <header class="border-bottom pb-3 mb-3">
                        <h3 class="h5 mb-1">菸害防制法 罰則專區</h3>
                        <p class="small hp-text-muted mb-0">
                            <i class="bi bi-journal-text me-1"></i>第二十三條 至 第三十三條
                        </p>
                    </header>
                    <pre class="hp-prose">
第二十三條　　違反第五條或第十條第一項規定者，處新臺幣一萬元以上五萬元以下罰鍰，並得按次連續處罰。
第二十四條　　製造或輸入違反第六條第一項、第二項或第七條第一項規定之菸品者，處新臺幣一百萬元以上五百萬元以下罰鍰，並令限期回收；屆期未回收者，按次連續處罰，違規之菸品沒入並銷毀之。
販賣違反第六條第一項、第二項或第七條第一項規定之菸品者，處新臺幣一萬元以上五萬元以下罰鍰。
第二十五條　　違反第八條第一項規定者，處新臺幣十萬元以上五十萬元以下罰鍰，並令限期申報；屆期未申報者，按次連續處罰。
規避、妨礙或拒絕中央主管機關依第八條第二項規定所為之取樣檢查（驗）者，處新臺幣十萬元以上五十萬元以下罰鍰。
第二十六條　　製造或輸入業者，違反第九條各款規定者，處新臺幣五百萬元以上二千五百萬元以下罰鍰，並按次連續處罰。
廣告業或傳播媒體業者違反第九條各款規定，製作菸品廣告或接受傳播或刊載者，處新臺幣二十萬元以上一百萬元以下罰鍰，並按次處罰。
違反第九條各款規定，除前二項另有規定者外，處新臺幣十萬元以上五十萬元以下罰鍰，並按次連續處罰。
第二十七條　　違反第十一條規定者，處新臺幣二千元以上一萬元以下罰鍰。
第二十八條　　違反第十二條第一項規定者，應令其接受戒菸教育；行為人未滿十八歲且未結婚者，並應令其父母或監護人使其到場。
無正當理由未依通知接受戒菸教育者，處新臺幣二千元以上一萬元以下罰鍰，並按次連續處罰；行為人未滿十八歲且未結婚者，處罰其父母或監護人。
第一項戒菸教育之實施辦法，由中央主管機關定之。
第二十九條　　違反第十三條規定者，處新臺幣一萬元以上五萬元以下罰鍰。
第三十條　　製造或輸入業者，違反第十四條規定者，處新臺幣一萬元以上五萬元以下罰鍰，並令限期回收；屆期未回收者，按次連續處罰。
販賣業者違反第十四條規定者，處新臺幣一千元以上三千元以下罰鍰。
第三十一條　　違反第十五條第一項或第十六條第一項規定者，處新臺幣二千元以上一萬元以下罰鍰。
違反第十五條第二項、第十六條第二項或第三項規定者，處新臺幣一萬元以上五萬元以下罰鍰，並令限期改正；屆期未改正者，得按次連續處罰。
第三十二條　　違反本法規定，經依第二十三條至前條規定處罰者，得併公告被處分人及其違法情形。
第三十三條　　本法所定罰則，除第二十五條規定由中央主管機關處罰外，由直轄市、縣（市）主管機關處罰之。</pre>
                </article>

                <!-- 癌症防治 -->
                <article class="tab-pane fade" id="pane-cancer" role="tabpanel" aria-labelledby="tab-cancer" tabindex="0">
                    <header class="border-bottom pb-3 mb-3">
                        <h3 class="h5 mb-1">降低罹癌風險 建構健康生活型態</h3>
                        <p class="small hp-text-muted mb-0">
                            <i class="bi bi-pencil me-1"></i>撰文：徐文媛
                            <span class="mx-2">|</span>
                            <i class="bi bi-chat-quote me-1"></i>諮詢：衛生署國民健康局副局長趙坤郁
                            <span class="mx-2">|</span>
                            <i class="bi bi-calendar3 me-1"></i><time datetime="2010-01-20">2010 / 01 / 20</time>
                        </p>
                    </header>
                    <pre class="hp-prose">
癌症防治 三管齊下  Part 1 降低罹癌風險建構健康生活型態

致癌的因素很多，而且往往就存在於我們周遭環境及日常生活中。唯有正常飲食、適當運動、遠離致癌因子、養成健康行為與生活習慣，並改善生活環境品質，才能減少罹癌的危機。
形塑健康生活新價值觀
「健康生活型態」牽涉的範圍很廣，衛生署國民健康局副局長趙坤郁表示，做為國家癌症防治政策的一環，應優先選擇具實證研究基礎的指標，所以健康飲食、菸害防制、檳榔防制及建立運動習慣，都是目前積極推動的衛生政策。
生活型態需要長時間建立，所以要改變民眾健康生活型態，必須設定出各項目標策略和衡量指標，設法營造有助達成目標的軟、硬體環境，這些工作往往需要跨部門，甚至從民間社團、社區等基層的參與，才能讓議題逐漸發酵，達到社會價值的建立及風氣的改變。例如在健康飲食方面，至少需要健康局與食品衛生處（未來即將成立的食品藥物管理局）合作，除了宣導正確的飲食習慣，也要為民眾吃的健康把關，避免汙染等有害食物流入巿面。
在推廣動態生活，建立國人運動習慣上，透過訂定國人健康體能指標，調查全國及各縣巿的運動盛行率，並以每年提升0.5%為目標，結合體育主管單位及25縣巿政府同步進行政策的倡議及執行。以最容易、最安全的健走運動為例，現在11 月11日「健走日」已成為許多縣巿政府的重要活動；而去年健康局選擇竹北、屏東、新莊三個縣轄巿，調查健康體能自治性環境的策略指標及調查評估方法，也成為今年體委會要求各縣巿建置運動地圖時的重要參考。
建構健康生活型態是「預防勝於治療」的積極實現，不只能降低罹癌風險，也有助降低其他現代文明病的發生，長期來看是最具經濟效益的健康投資。趙坤郁強調，在全球化浪潮下，我們的飲食、嗜好...等生活型態與西方國家愈來愈趨近，疾病型態也可能逐漸接近，必須及早提出因應措施。

資料來源：行政院衛生署衛生報導139期</pre>
                </article>

                <!-- 慢性病防治 -->
                <article class="tab-pane fade" id="pane-chron" role="tabpanel" aria-labelledby="tab-chron" tabindex="0">
                    <header class="border-bottom pb-3 mb-3">
                        <h3 class="h5 mb-1">長期憋尿 泌尿系統問題多</h3>
                        <p class="small hp-text-muted mb-0">
                            <i class="bi bi-journal-text me-1"></i>中央健康保險局雙月刊第98期
                            <span class="mx-2">|</span>
                            <i class="bi bi-pencil me-1"></i>文／游小雯
                            <span class="mx-2">|</span>
                            <i class="bi bi-calendar3 me-1"></i><time datetime="2012-08-10">2012 / 08 / 10</time>
                        </p>
                    </header>
                    <pre class="hp-prose">
諮詢／郭育成（台北市立聯合醫院陽明院區泌尿科主任）

膀胱是中空、有彈性的肉囊， 約有400c.c.的容積，可暫存由腎臟製造、經輸尿管輸送下來的尿液。一般人排尿量每回約200到350c.c.，每天至少要有4到8次排尿次數才算正常；如果膀胱已存有近400c.c的尿液卻未排出，就會有尿很急、膀胱很脹的感覺，所謂的「憋尿」，就是讓膀胱經常撐在「脹滿」的狀態，沒有適時地清空排尿。「就像水溝的水沒有在流動一樣！」台北市立聯合醫院陽明院區泌尿科郭育成主任表示，把尿憋在膀胱中，就像是沒有流動的髒水，很容易滋生細菌及沉澱物，長期下來，不僅泌尿道易受感染、影響膀胱收縮力，甚至會造成腎臟永久傷害，不僅無法完全修復，還要終身小心照護。
憋尿會憋出哪些毛病呢？
「憋尿、排尿」這個看似簡單的動作，對身體健康卻有極大的影響，以下4項就是一般人最常憋出問題的病症：
1、尿道感染：
憋尿時，長時間無尿液經過尿道，無法將尿道開口的細菌沖走，大量細菌在尿道聚集，很容易引起發炎，尤其尿流不通暢的人（如前列腺肥大、障礙性排尿或結石），尿道感染的發生率，會比正常人高出許多。
2、膀胱發炎：
憋尿使膀胱長期脹大，膀胱壁血管受到壓迫，膀胱黏膜就會缺血，只要身體抵抗力差時，細菌趁虛而入即造成「急性膀胱炎」。膀胱炎發生時，膀胱壁變得較敏感，儘管積存的尿液不多，也會急著想上廁所，但一次卻只能尿出一點點；而大部份的膀胱炎，尿道粘膜通常也處於發炎狀態，所以會出現「燒灼感」，此外通常還會有「血尿」的情況發生。比較嚴重的膀胱炎甚至會發燒、併發腎臟炎等症狀。
3、前列腺炎與副睪丸炎：
男性若水份攝取不夠或憋尿使排尿次數過少，細菌就有機會透過尿道引發感染；嚴重的話，尿液甚至會經由輸精管倒流至前列腺或副睪丸，而引發前列腺炎或副睪丸炎，最嚴重可導致不孕，增加更多棘手的併發症。
4、膀胱損傷：
長期憋尿會使膀胱過度脹扯、壁肌肉層變薄，如果出現纖維化的情形會影響彈性，導致膀胱收縮力因此變差，而有疼痛、頻尿或尿不乾淨等後遺症；如果神經受損嚴重，膀胱括約肌無力，甚至會造成尿不出來的後果。平日勤保健，別讓憋尿造成終身遺憾許多上班族與公司主管，一忙或開會經常就是好幾個小時，為了不影響進度，常忘了上廁所，即使有尿意也盡量憋著，憋尿不只是造成泌尿系統發炎，尿液回流到腎臟也會造成腎積水引發尿毒症等併發症，最後很可能靠洗腎度日了！
平日盡量力行以下4項原則：
1、多喝水、不憋尿。
2、注意個人衛生：如多淋浴少盆浴、女生在如廁後記得由前往後擦、性行為前後（不論男女）應注意會陰部、肛門口及尿道口的清潔工作。
3、正常的飲食習慣及充分的休息與睡眠，以增加抵抗力及免疫力。
4、多注意及控制易引發膀胱炎的疾病：如糖尿病、尿路結石、攝護腺肥大等。
如果民眾發現自己解尿不舒服時，一定要在第一時間就診，讓醫師採用檢體對症下藥，只要沒有其他的特殊問題併存，同時能接受完整療程的抗生素治療，通常一星期左右即可痊癒。不過服藥的時間及用量絕對要遵照醫師囑咐，如果自行隨意停藥或不按時服用，很可能會造成殘存的細菌出現抗藥性，非但原本的症狀無法痊癒，還可能帶來慢性泌尿道發炎、尿路結石、腎臟功能受損等併發症，千萬要特別注意。</pre>
                </article>

            </div>
        </div>
    </div>
</section>
