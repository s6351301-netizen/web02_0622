<?php
/**
 * 會員登入
 */
?>
<div class="hp-auth">
    <div class="hp-auth__card">
        <div class="hp-auth__head">
            <i class="bi bi-shield-lock"></i>
            <h1 class="h5 text-white mt-2 mb-1">會員登入</h1>
            <p class="mb-0 small" style="opacity:.85">登入後即可按讚、參與問卷調查</p>
        </div>

        <div class="hp-auth__body">
            <form onsubmit="event.preventDefault(); login();" novalidate>
                <div class="mb-3">
                    <label class="form-label" for="acc">帳號</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" class="form-control" name="acc" id="acc"
                               autocomplete="username" placeholder="請輸入帳號" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label" for="pw">密碼</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-key"></i></span>
                        <input type="password" class="form-control" name="pw" id="pw"
                               autocomplete="current-password" placeholder="請輸入密碼" required>
                        <button class="btn btn-outline-secondary" type="button" id="togglePw"
                                aria-label="顯示或隱藏密碼">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="bi bi-box-arrow-in-right me-1"></i>登入
                    </button>
                    <button type="button" class="btn btn-soft" onclick="$('#acc,#pw').val('').first().focus()">
                        <i class="bi bi-eraser me-1"></i>清除
                    </button>
                </div>
            </form>

            <hr class="hp-divider-soft my-4">

            <div class="d-flex justify-content-between small">
                <a href="?do=forgot"><i class="bi bi-question-circle me-1"></i>忘記密碼</a>
                <a href="?do=reg"><i class="bi bi-person-plus me-1"></i>尚未註冊</a>
            </div>
        </div>
    </div>
</div>

<script>
    $("#togglePw").on("click", function () {
        var $pw = $("#pw");
        var show = $pw.attr("type") === "password";
        $pw.attr("type", show ? "text" : "password");
        $(this).find("i").attr("class", show ? "bi bi-eye-slash" : "bi bi-eye");
    });

    function notify(msg, type) {
        if (window.hpToast) { window.hpToast(msg, type); } else { alert(msg); }
    }

    function login() {
        var user = { "acc": $("#acc").val(), "pw": $("#pw").val() };

        if (user.acc === "" || user.pw === "") {
            notify("請輸入帳號與密碼", "warning");
            return;
        }

        $.get("./api/chk_acc.php", user, function (res) {
            if (parseInt(res) > 0) {
                $.post("./api/chk_pw.php", user, function (res) {
                    if (parseInt(res) > 0) {
                        location.href = (user.acc === 'admin') ? 'admin.php' : 'index.php?do=main';
                    } else {
                        notify("密碼錯誤", "danger");
                        $('#acc,#pw').val('');
                    }
                });
            } else {
                notify("查無帳號", "danger");
                $('#acc,#pw').val('');
            }
        });
    }
</script>
