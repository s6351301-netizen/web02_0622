<?php
/**
 * 會員註冊
 */
?>
<div class="hp-auth">
    <div class="hp-auth__card">
        <div class="hp-auth__head">
            <i class="bi bi-person-plus"></i>
            <h1 class="h5 text-white mt-2 mb-1">會員註冊</h1>
            <p class="mb-0 small" style="opacity:.85">加入社群，一起分享健康生活</p>
        </div>

        <div class="hp-auth__body">
            <div class="alert alert-brand d-flex gap-2 py-2 small" role="note">
                <i class="bi bi-info-circle-fill"></i>
                <span>請設定您要註冊的帳號及密碼（最長 12 個字元）</span>
            </div>

            <form onsubmit="event.preventDefault(); reg();" novalidate>
                <div class="mb-3">
                    <label class="form-label" for="acc">
                        <span class="badge text-bg-brand me-1">Step 1</span>登入帳號
                    </label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" class="form-control" name="acc" id="acc" maxlength="12"
                               autocomplete="username" placeholder="12 個字元以內" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="pw">
                        <span class="badge text-bg-brand me-1">Step 2</span>登入密碼
                    </label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-key"></i></span>
                        <input type="password" class="form-control" name="pw" id="pw" maxlength="12"
                               autocomplete="new-password" placeholder="12 個字元以內" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="pw2">
                        <span class="badge text-bg-brand me-1">Step 3</span>再次確認密碼
                    </label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-key-fill"></i></span>
                        <input type="password" class="form-control" name="pw2" id="pw2" maxlength="12"
                               autocomplete="new-password" placeholder="請再輸入一次密碼" required>
                    </div>
                    <div class="form-text" id="pwHint"></div>
                </div>

                <div class="mb-4">
                    <label class="form-label" for="email">
                        <span class="badge text-bg-brand me-1">Step 4</span>電子信箱
                    </label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" class="form-control" name="email" id="email"
                               autocomplete="email" placeholder="忘記密碼時使用" required>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="bi bi-check2-circle me-1"></i>註冊
                    </button>
                    <button type="button" class="btn btn-soft"
                            onclick="$('#acc,#pw,#pw2,#email').val(''); $('#pwHint').text('');">
                        <i class="bi bi-eraser me-1"></i>清除
                    </button>
                </div>
            </form>

            <hr class="hp-divider-soft my-4">

            <p class="text-center small mb-0">
                已經有帳號了？<a href="?do=login">前往登入</a>
            </p>
        </div>
    </div>
</div>

<script>
    function notify(msg, type) {
        if (window.hpToast) { window.hpToast(msg, type); } else { alert(msg); }
    }

    $("#pw2, #pw").on("input", function () {
        var pw = $("#pw").val(), pw2 = $("#pw2").val();
        var $hint = $("#pwHint");
        if (!pw2) { $hint.text("").removeClass("text-danger text-success"); return; }
        if (pw === pw2) {
            $hint.text("兩次密碼一致").removeClass("text-danger").addClass("text-success");
        } else {
            $hint.text("兩次輸入的密碼不相同").removeClass("text-success").addClass("text-danger");
        }
    });

    function reg() {
        var user = {
            'acc': $("#acc").val(),
            'pw': $("#pw").val(),
            'pw2': $("#pw2").val(),
            'email': $("#email").val()
        };

        if (user.acc === "" || user.pw === "" || user.pw2 === "" || user.email === "") {
            notify("不可空白", "warning");
        } else if (user.pw !== user.pw2) {
            notify("密碼錯誤", "danger");
        } else {
            $.get("api/chk_acc.php", user, function (res) {
                if (parseInt(res) > 0) {
                    notify("帳號重複", "danger");
                } else {
                    $.post("api/reg.php", user, function () {
                        notify("註冊成功，歡迎加入", "success");
                        setTimeout(function () { location.href = '?do=login'; }, 1200);
                    });
                }
            });
        }
    }
</script>
