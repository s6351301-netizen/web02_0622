<?php
/**
 * 講座訊息（籌備中）
 * ------------------------------------------------------------------
 * 原專案的「講座訊息」選單並未建立對應頁面，點選後會落回首頁。
 * 此頁提供明確的狀態說明與替代入口，避免使用者迷失。
 */
?>
<div class="card">
    <div class="card-body p-4 p-lg-5 text-center">
        <span class="hp-quick__icon mx-auto" style="width:72px;height:72px;font-size:2rem">
            <i class="bi bi-calendar2-event"></i>
        </span>

        <h2 class="h4 mt-3 mb-2">講座訊息籌備中</h2>
        <p class="hp-text-muted mb-4" style="max-width:52ch;margin-inline:auto;line-height:2">
            健康講座與活動報名功能正在規劃中，開放後將於此頁公告場次時間、地點與報名方式。
            在此之前，歡迎您先閱讀站上的衛教文章，或參與問卷調查表達您的想法。
        </p>

        <div class="d-flex flex-wrap justify-content-center gap-2">
            <a class="btn btn-primary" href="?do=news"><i class="bi bi-newspaper me-1"></i>閱讀最新文章</a>
            <a class="btn btn-outline-primary" href="?do=po"><i class="bi bi-journals me-1"></i>瀏覽分類網誌</a>
            <a class="btn btn-soft" href="?do=que"><i class="bi bi-clipboard2-pulse me-1"></i>參與問卷調查</a>
        </div>

        <hr class="hp-divider-soft my-4">

        <p class="small hp-text-muted mb-0">
            <i class="bi bi-envelope me-1"></i>
            如有講座合作或場次詢問，請來信
            <a href="mailto:health@test.labor.gov.tw">health@test.labor.gov.tw</a>
        </p>
    </div>
</div>
