<?php
/**
 * 參與投票：顯示單一問卷的所有選項並送出投票
 */
$subject = $Que->find($_GET['id'] ?? 0);
$options = !empty($subject) ? $Que->all(['main_id' => $subject['id']]) : [];
?>

<?php if (empty($subject)): ?>
    <div class="card">
        <div class="card-body">
            <div class="hp-empty">
                <i class="bi bi-exclamation-circle"></i>
                找不到這份問卷
                <div class="mt-3"><a class="btn btn-soft" href="?do=que">返回問卷列表</a></div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="row justify-content-center">
        <div class="col-lg-9 col-xl-8">
            <form action="./api/vote.php" method="post" class="card">
                <div class="card-header d-flex align-items-center gap-2">
                    <i class="bi bi-clipboard2-pulse text-primary"></i>
                    <span>問卷投票</span>
                </div>

                <div class="card-body p-4">
                    <h2 class="h5 mb-1"><?= e($subject['text']) ?></h2>
                    <p class="small hp-text-muted mb-4">
                        <i class="bi bi-people me-1"></i>目前累計 <?= (int) $subject['vote'] ?> 票
                        <span class="mx-2">|</span>
                        <i class="bi bi-info-circle me-1"></i>本題為單選，送出後將顯示統計結果
                    </p>

                    <fieldset>
                        <legend class="visually-hidden">請選擇一個選項</legend>
                        <div class="list-group">
                            <?php foreach ($options as $i => $option): ?>
                                <label class="list-group-item list-group-item-action d-flex align-items-center gap-3 py-3">
                                    <input class="form-check-input flex-shrink-0 m-0" type="radio"
                                           name="vote" value="<?= (int) $option['id'] ?>"
                                        <?= $i === 0 ? 'required' : '' ?>>
                                    <span><?= e($option['text']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </fieldset>

                    <?php if (empty($options)): ?>
                        <div class="hp-empty"><i class="bi bi-inbox"></i>這份問卷還沒有設定選項</div>
                    <?php endif; ?>
                </div>

                <div class="card-footer bg-transparent d-flex flex-wrap gap-2 justify-content-between p-3">
                    <a class="btn btn-soft" href="?do=que"><i class="bi bi-arrow-left me-1"></i>返回列表</a>
                    <div class="d-flex gap-2">
                        <a class="btn btn-outline-primary" href="?do=result&id=<?= (int) $subject['id'] ?>">
                            <i class="bi bi-bar-chart-line me-1"></i>查看結果
                        </a>
                        <button class="btn btn-primary px-4" type="submit" <?= empty($options) ? 'disabled' : '' ?>>
                            <i class="bi bi-send me-1"></i>我要投票
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>
