<?php
/**
 * 人氣文章：依按讚數排行，可開啟燈箱閱讀全文並按讚
 */
$total  = $News->count(['sh' => 1, 'del' => 0]);
$div    = 5;
$pages  = ceil($total / $div);
$now    = (int) ($_GET['p'] ?? 1);
$start  = ($now - 1) * $div;
$posts  = $News->all(['sh' => 1, 'del' => 0], " order by good desc limit $start,$div");
$hpUser = $_SESSION['login'] ?? null;
$hpMax  = 0;
foreach ($posts as $p) {
    $hpMax = max($hpMax, (int) $p['good']);
}
$hpMax = $hpMax > 0 ? $hpMax : 1;
?>

<div class="card">
    <div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2">
        <span><i class="bi bi-fire text-danger me-2"></i>人氣排行榜</span>
        <span class="badge text-bg-brand">共 <?= (int) $total ?> 篇．第 <?= $now ?> / <?= max(1, (int) $pages) ?> 頁</span>
    </div>

    <?php if (empty($posts)): ?>
        <div class="card-body">
            <div class="hp-empty"><i class="bi bi-inbox"></i>目前沒有可顯示的文章</div>
        </div>
    <?php else: ?>
        <ul class="list-group list-group-flush">
            <?php foreach ($posts as $idx => $post): ?>
                <?php
                $pid   = (int) $post['id'];
                $rank  = $start + $idx + 1;
                $good  = (int) $post['good'];
                $ratio = round($good / $hpMax * 100);
                $liked = $hpUser !== null
                    && $Log->count(['user' => $hpUser, 'news' => $pid]) > 0;
                ?>
                <li class="list-group-item p-3 p-md-4">
                    <div class="d-flex align-items-start gap-3">
                        <span class="hp-rank hp-rank--<?= $rank ?>"><?= $rank ?></span>

                        <div class="flex-grow-1 min-w-0">
                            <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
                                <span class="badge text-bg-brand"><?= e($post['type']) ?></span>
                                <button type="button"
                                        class="btn btn-link p-0 fw-bold text-start text-body text-decoration-none"
                                        data-bs-toggle="modal" data-bs-target="#popModal<?= $pid ?>">
                                    <?= e($post['title']) ?>
                                </button>
                            </div>

                            <p class="small hp-text-muted hp-clamp-2 mb-2">
                                <?= e(mb_substr($post['content'], 0, 80)) ?>…
                            </p>

                            <div class="d-flex flex-wrap align-items-center gap-3">
                                <div class="progress flex-grow-1" style="height:8px;max-width:280px"
                                     role="progressbar" aria-label="人氣比例"
                                     aria-valuenow="<?= $ratio ?>" aria-valuemin="0" aria-valuemax="100">
                                    <div class="progress-bar" style="width:<?= $ratio ?>%"></div>
                                </div>
                                <span class="small fw-semibold text-primary">
                                    <i class="bi bi-hand-thumbs-up-fill me-1"></i><?= $good ?> 個人說讚
                                </span>
                                <?php if ($hpUser !== null): ?>
                                    <button type="button"
                                            class="hp-like<?= $liked ? ' is-liked' : '' ?>"
                                            onclick="good(<?= $pid ?>)">
                                        <i class="bi <?= $liked ? 'bi-heart-fill' : 'bi-heart' ?>"></i>
                                        <?= $liked ? '收回讚' : '讚' ?>
                                    </button>
                                <?php else: ?>
                                    <a class="hp-like" href="?do=login">
                                        <i class="bi bi-box-arrow-in-right"></i>登入後可按讚
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <button type="button" class="btn btn-sm btn-soft flex-shrink-0 d-none d-md-inline-flex"
                                data-bs-toggle="modal" data-bs-target="#popModal<?= $pid ?>">
                            <i class="bi bi-book me-1"></i>閱讀
                        </button>
                    </div>
                </li>

                <!-- 全文燈箱 -->
                <div class="modal fade" id="popModal<?= $pid ?>" tabindex="-1"
                     aria-labelledby="popModalTitle<?= $pid ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <div>
                                    <span class="badge text-bg-brand mb-2"><?= e($post['type']) ?></span>
                                    <h2 class="modal-title h5 mb-0" id="popModalTitle<?= $pid ?>">
                                        <?= e($post['title']) ?>
                                    </h2>
                                </div>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="關閉"></button>
                            </div>
                            <div class="modal-body">
                                <div class="hp-prose"><?= $post['content'] ?></div>
                            </div>
                            <div class="modal-footer justify-content-between">
                                <span class="badge text-bg-brand">
                                    <i class="bi bi-hand-thumbs-up me-1"></i><?= $good ?> 個人說讚
                                </span>
                                <button type="button" class="btn btn-soft" data-bs-dismiss="modal">關閉</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if ($pages > 1): ?>
        <div class="card-footer bg-transparent d-flex justify-content-center py-3">
            <nav aria-label="人氣文章分頁">
                <ul class="pagination mb-0">
                    <li class="page-item<?= $now <= 1 ? ' disabled' : '' ?>">
                        <a class="page-link" href="?do=pop&p=<?= $now - 1 ?>" aria-label="上一頁">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                        <li class="page-item<?= $i === $now ? ' active' : '' ?>">
                            <a class="page-link" href="?do=pop&p=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item<?= $now >= $pages ? ' disabled' : '' ?>">
                        <a class="page-link" href="?do=pop&p=<?= $now + 1 ?>" aria-label="下一頁">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<script>
    function good(id) {
        $.post("./api/good.php", { id: id }, function () {
            location.reload();
        });
    }
</script>
