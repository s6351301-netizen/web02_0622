<?php
/**
 * 投票結果：以長條圖呈現各選項得票比例
 */
$subject = $Que->find($_GET['id'] ?? 0);
$options = !empty($subject) ? $Que->all(['main_id' => $subject['id']]) : [];
$hpUser  = $_SESSION['login'] ?? null;
?>

<?php if (empty($subject)): ?>
    <div class="card">
        <div class="card-body">
            <div class="hp-empty">
                <i class="bi bi-exclamation-circle"></i>
                找不到這份問卷
                <div class="mt-3"><a class="btn btn-soft" href="?do=que">返回問卷列表</a></div>
            </div>
        </div>
    </div>
<?php else: ?>
    <?php
    $totalVote = (int) $subject['vote'];
    $divisor   = $totalVote > 0 ? $totalVote : 1;   // 避免分母為零
    $topVote   = 0;
    foreach ($options as $o) {
        $topVote = max($topVote, (int) $o['vote']);
    }
    ?>
    <div class="row justify-content-center">
        <div class="col-lg-9 col-xl-8">
            <div class="card">
                <div class="card-header d-flex align-items-center gap-2">
                    <i class="bi bi-bar-chart-line text-primary"></i>
                    <span>投票結果</span>
                </div>

                <div class="card-body p-4">
                    <h2 class="h5 mb-1"><?= e($subject['text']) ?></h2>
                    <p class="small hp-text-muted mb-4">
                        <i class="bi bi-people me-1"></i>總投票數 <strong class="text-primary"><?= $totalVote ?></strong> 票
                    </p>

                    <?php if (empty($options)): ?>
                        <div class="hp-empty"><i class="bi bi-inbox"></i>這份問卷還沒有設定選項</div>
                    <?php else: ?>
                        <ul class="list-unstyled mb-0 d-grid gap-4">
                            <?php foreach ($options as $option): ?>
                                <?php
                                $vote    = (int) $option['vote'];
                                $percent = round($vote / $divisor * 100);
                                $isTop   = ($topVote > 0 && $vote === $topVote);
                                ?>
                                <li>
                                    <div class="d-flex flex-wrap justify-content-between gap-2 mb-2">
                                        <span class="fw-semibold">
                                            <?php if ($isTop): ?>
                                                <i class="bi bi-trophy-fill text-warning me-1"></i>
                                            <?php endif; ?>
                                            <?= e($option['text']) ?>
                                        </span>
                                        <span class="badge text-bg-brand flex-shrink-0">
                                            <?= $vote ?> 票（<?= $percent ?>%）
                                        </span>
                                    </div>
                                    <div class="progress" style="height:14px" role="progressbar"
                                         aria-label="<?= e($option['text']) ?> 得票比例"
                                         aria-valuenow="<?= $percent ?>" aria-valuemin="0" aria-valuemax="100">
                                        <div class="progress-bar<?= $isTop ? ' bg-brand-gradient' : '' ?>"
                                             style="width:<?= $percent ?>%"></div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>

                <div class="card-footer bg-transparent d-flex flex-wrap gap-2 justify-content-between p-3">
                    <a class="btn btn-soft" href="?do=que"><i class="bi bi-arrow-left me-1"></i>返回列表</a>
                    <?php if ($hpUser !== null): ?>
                        <a class="btn btn-primary" href="?do=vote&id=<?= (int) $subject['id'] ?>">
                            <i class="bi bi-check2-square me-1"></i>我要投票
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
