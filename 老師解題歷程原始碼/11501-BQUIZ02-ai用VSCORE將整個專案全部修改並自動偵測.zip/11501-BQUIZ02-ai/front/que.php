<?php
/**
 * 問卷調查：列出已開放的問卷，可查看結果或參與投票
 */
$ques   = $Que->all(['main_id' => 0, 'sh' => 1]);
$hpUser = $_SESSION['login'] ?? null;
?>

<?php if ($hpUser === null): ?>
    <div class="alert alert-brand d-flex align-items-center gap-2" role="alert">
        <i class="bi bi-info-circle-fill"></i>
        <span>參與投票需先登入會員，您仍可自由查看各問卷的統計結果。</span>
        <a class="btn btn-sm btn-primary ms-auto flex-shrink-0" href="?do=login">立即登入</a>
    </div>
<?php endif; ?>

<?php if (empty($ques)): ?>
    <div class="card">
        <div class="card-body">
            <div class="hp-empty"><i class="bi bi-clipboard2-x"></i>目前沒有開放中的問卷</div>
        </div>
    </div>
<?php else: ?>
    <div class="row g-3">
        <?php foreach ($ques as $idx => $que): ?>
            <?php
            $qid     = (int) $que['id'];
            $options = $Que->count(['main_id' => $qid]);
            ?>
            <div class="col-md-6 col-xxl-4">
                <div class="card h-100 hp-card-hover">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex align-items-center gap-2 mb-3">
                            <span class="hp-rank"><?= $idx + 1 ?></span>
                            <span class="badge text-bg-success">
                                <i class="bi bi-broadcast me-1"></i>開放中
                            </span>
                        </div>

                        <h2 class="h6 mb-3 lh-base"><?= e($que['text']) ?></h2>

                        <div class="d-flex flex-wrap gap-3 small hp-text-muted mb-3">
                            <span><i class="bi bi-people me-1"></i>累計 <strong class="text-primary"><?= (int) $que['vote'] ?></strong> 票</span>
                            <span><i class="bi bi-list-ul me-1"></i><?= (int) $options ?> 個選項</span>
                        </div>

                        <div class="mt-auto d-flex gap-2">
                            <?php if ($hpUser !== null): ?>
                                <a class="btn btn-primary flex-fill" href="?do=vote&id=<?= $qid ?>">
                                    <i class="bi bi-check2-square me-1"></i>參與投票
                                </a>
                            <?php else: ?>
                                <a class="btn btn-outline-primary flex-fill" href="?do=login">
                                    <i class="bi bi-lock me-1"></i>請先登入
                                </a>
                            <?php endif; ?>
                            <a class="btn btn-soft flex-fill" href="?do=result&id=<?= $qid ?>">
                                <i class="bi bi-bar-chart-line me-1"></i>看結果
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
