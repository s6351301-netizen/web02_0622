<?php
/**
 * 後台入口
 * ------------------------------------------------------------------
 * 依 ?do= 參數載入 back/ 目錄下對應頁面，找不到時回到管理首頁。
 */
include_once "./api/db.php";
include_once "./inc/helpers.php";

$do   = $_GET['do'] ?? 'main';
$file = "./back/$do.php";

if (!file_exists($file)) {
    $do   = 'main';
    $file = "./back/main.php";
}

$HP_AREA = 'admin';
$HP_PAGE = $HP_ADMIN_NAV[$do] ?? $HP_ADMIN_EXTRA[$do] ?? $HP_ADMIN_NAV['main'];

include "./inc/head.php";
?>

<div class="row g-4">
    <!-- 側邊選單（桌機） -->
    <div class="col-lg-3 col-xl-2 d-none d-lg-block">
        <aside class="hp-sidebar">
            <?php include "./inc/admin_nav.php"; ?>
        </aside>
    </div>

    <!-- 內容區 -->
    <div class="col-lg-9 col-xl-10">
        <div class="hp-page-head hp-fade-up">
            <h1 class="hp-page-title">
                <i class="bi <?= e($HP_PAGE['icon']) ?>" aria-hidden="true"></i>
                <?= e($HP_PAGE['title']) ?>
            </h1>
            <nav aria-label="麵包屑">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="admin.php"><i class="bi bi-sliders me-1"></i>後台管理</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?= e($HP_PAGE['label']) ?></li>
                </ol>
            </nav>
        </div>

        <div class="hp-fade-up">
            <?php include $file; ?>
        </div>
    </div>
</div>

<!-- 側邊選單（行動裝置） -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="hpAdminNav" aria-labelledby="hpAdminNavTitle">
    <div class="offcanvas-header border-bottom">
        <h2 class="offcanvas-title h6 mb-0" id="hpAdminNavTitle">
            <i class="bi bi-sliders me-2"></i>後台管理
        </h2>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="關閉"></button>
    </div>
    <div class="offcanvas-body">
        <?php include "./inc/admin_nav.php"; ?>
    </div>
</div>

<?php include "./inc/footer.php"; ?>
