<?php
/**
 * 後台儀表板：關鍵數據總覽與快速操作
 */
$hpMemCount     = $Mem->count();
$hpNewsAll      = $News->count(['del' => 0]);
$hpNewsShow     = $News->count(['sh' => 1, 'del' => 0]);
$hpNewsHide     = $hpNewsAll - $hpNewsShow;
$hpQueCount     = $Que->count(['main_id' => 0]);
$hpQueOpen      = $Que->count(['main_id' => 0, 'sh' => 1]);
$hpVoteTotalRow = $Que->q("select sum(`vote`) as 'sum' from `que` where `main_id`=0");
$hpVoteTotal    = $hpVoteTotalRow[0]['sum'] ?? 0;
$hpLikeRow      = $News->q("select sum(`good`) as 'sum' from `news` where `del`=0");
$hpLikeTotal    = $hpLikeRow[0]['sum'] ?? 0;
$hpRecent       = $News->all(['del' => 0], " order by `id` desc limit 5");
$hpTrend        = $Total->all("", " order by `date` desc limit 7");
$hpTrendMax     = 1;
foreach ($hpTrend as $t) {
    $hpTrendMax = max($hpTrendMax, (int) $t['total']);
}
$hpTrend = array_reverse($hpTrend);
?>

<!-- 數據總覽 -->
<section class="mb-4" aria-label="數據總覽">
    <div class="row g-3">
        <div class="col-6 col-xl-3">
            <div class="hp-stat">
                <span class="hp-stat__icon"><i class="bi bi-people-fill"></i></span>
                <div>
                    <div class="hp-stat__value"><?= (int) $hpMemCount ?></div>
                    <div class="hp-stat__label">註冊會員</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="hp-stat hp-stat--sky">
                <span class="hp-stat__icon"><i class="bi bi-newspaper"></i></span>
                <div>
                    <div class="hp-stat__value"><?= (int) $hpNewsAll ?></div>
                    <div class="hp-stat__label">文章總數（顯示 <?= (int) $hpNewsShow ?> / 隱藏 <?= (int) $hpNewsHide ?>）</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="hp-stat hp-stat--accent">
                <span class="hp-stat__icon"><i class="bi bi-clipboard2-pulse"></i></span>
                <div>
                    <div class="hp-stat__value"><?= (int) $hpQueCount ?></div>
                    <div class="hp-stat__label">問卷數（開放 <?= (int) $hpQueOpen ?>）</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="hp-stat hp-stat--rose">
                <span class="hp-stat__icon"><i class="bi bi-hand-thumbs-up-fill"></i></span>
                <div>
                    <div class="hp-stat__value"><?= (int) $hpLikeTotal ?></div>
                    <div class="hp-stat__label">累計按讚數</div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="row g-4">
    <!-- 近七日瀏覽量 -->
    <div class="col-xl-7">
        <div class="card h-100">
            <div class="card-header d-flex align-items-center justify-content-between">
                <span><i class="bi bi-bar-chart-line text-primary me-2"></i>近期瀏覽量</span>
                <span class="badge text-bg-brand">投票總數 <?= (int) $hpVoteTotal ?></span>
            </div>
            <div class="card-body">
                <?php if (empty($hpTrend)): ?>
                    <div class="hp-empty"><i class="bi bi-graph-up"></i>尚無瀏覽紀錄</div>
                <?php else: ?>
                    <ul class="list-unstyled mb-0 d-grid gap-3">
                        <?php foreach ($hpTrend as $row): ?>
                            <?php $w = round((int) $row['total'] / $hpTrendMax * 100); ?>
                            <li class="d-flex align-items-center gap-3">
                                <span class="small hp-text-muted flex-shrink-0 text-nowrap" style="width:112px">
                                    <?= e(date('m/d', strtotime($row['date']))) ?>
                                    <?= e(hp_weekday(strtotime($row['date']))) ?>
                                </span>
                                <div class="progress flex-grow-1" style="height:12px" role="progressbar"
                                     aria-label="瀏覽量" aria-valuenow="<?= (int) $row['total'] ?>"
                                     aria-valuemin="0" aria-valuemax="<?= $hpTrendMax ?>">
                                    <div class="progress-bar bg-brand-gradient" style="width:<?= $w ?>%"></div>
                                </div>
                                <span class="fw-bold flex-shrink-0" style="width:48px;text-align:right">
                                    <?= (int) $row['total'] ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 最近文章 -->
    <div class="col-xl-5">
        <div class="card h-100">
            <div class="card-header d-flex align-items-center justify-content-between">
                <span><i class="bi bi-clock-history text-primary me-2"></i>最近文章</span>
                <a class="btn btn-sm btn-soft" href="?do=news">管理<i class="bi bi-chevron-right ms-1"></i></a>
            </div>
            <ul class="list-group list-group-flush">
                <?php if (empty($hpRecent)): ?>
                    <li class="list-group-item hp-empty"><i class="bi bi-inbox"></i>尚無文章</li>
                <?php else: ?>
                    <?php foreach ($hpRecent as $row): ?>
                        <li class="list-group-item d-flex align-items-center gap-2">
                            <i class="bi bi-file-earmark-text text-primary"></i>
                            <div class="flex-grow-1 min-w-0">
                                <div class="fw-semibold text-truncate" title="<?= e($row['title']) ?>">
                                    <?= e($row['title']) ?>
                                </div>
                                <small class="hp-text-muted"><?= e($row['type']) ?></small>
                            </div>
                            <span class="badge <?= $row['sh'] == 1 ? 'text-bg-success' : 'text-bg-secondary' ?> flex-shrink-0">
                                <?= $row['sh'] == 1 ? '顯示中' : '已隱藏' ?>
                            </span>
                        </li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<!-- 快速操作 -->
<section class="mt-4" aria-label="快速操作">
    <h2 class="hp-section-title">快速操作</h2>
    <div class="row g-3">
        <div class="col-6 col-lg-3">
            <a class="hp-quick" href="?do=add_news">
                <span class="hp-quick__icon"><i class="bi bi-file-earmark-plus"></i></span>
                <div class="hp-quick__title">新增文章</div>
                <p class="hp-quick__desc">發布新的衛教內容</p>
            </a>
        </div>
        <div class="col-6 col-lg-3">
            <a class="hp-quick" href="?do=news">
                <span class="hp-quick__icon"><i class="bi bi-list-check"></i></span>
                <div class="hp-quick__title">文章管理</div>
                <p class="hp-quick__desc">調整顯示狀態與刪除</p>
            </a>
        </div>
        <div class="col-6 col-lg-3">
            <a class="hp-quick" href="?do=acc">
                <span class="hp-quick__icon"><i class="bi bi-people"></i></span>
                <div class="hp-quick__title">帳號管理</div>
                <p class="hp-quick__desc">新增或刪除會員帳號</p>
            </a>
        </div>
        <div class="col-6 col-lg-3">
            <a class="hp-quick" href="?do=que">
                <span class="hp-quick__icon"><i class="bi bi-clipboard2-pulse"></i></span>
                <div class="hp-quick__title">問卷管理</div>
                <p class="hp-quick__desc">建立問卷與開關投票</p>
            </a>
        </div>
    </div>
</section>
