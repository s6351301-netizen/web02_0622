<?php
/**
 * 帳號管理：刪除既有會員、新增會員
 */
$mems = $Mem->all();
?>

<div class="row g-4">
    <!-- 會員列表 -->
    <div class="col-xl-7">
        <form action="./api/edit_acc.php" method="post" class="card h-100"
              onsubmit="return confirm('確定要刪除已勾選的帳號嗎？此動作無法復原。');">
            <div class="card-header d-flex align-items-center justify-content-between">
                <span><i class="bi bi-people text-primary me-2"></i>會員列表</span>
                <span class="badge text-bg-brand">共 <?= count($mems) ?> 位</span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 hp-table-min">
                    <thead>
                        <tr>
                            <th scope="col">帳號</th>
                            <th scope="col">密碼</th>
                            <th scope="col" class="text-center" style="width:90px">刪除</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($mems)): ?>
                            <tr>
                                <td colspan="3">
                                    <div class="hp-empty"><i class="bi bi-person-x"></i>目前沒有會員資料</div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($mems as $mem): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="hp-avatar" style="width:30px;height:30px;flex:0 0 30px;font-size:.8rem">
                                                <?= e(hp_initial($mem['acc'])) ?>
                                            </span>
                                            <span class="fw-semibold"><?= e($mem['acc']) ?></span>
                                            <?php if ($mem['acc'] === 'admin'): ?>
                                                <span class="badge text-bg-brand">管理員</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="font-monospace hp-text-muted">
                                        <?= str_repeat("•", strlen($mem['pw'])) ?>
                                    </td>
                                    <td class="text-center">
                                        <input class="form-check-input" type="checkbox" name="del[]"
                                               value="<?= (int) $mem['id'] ?>"
                                               aria-label="刪除帳號 <?= e($mem['acc']) ?>">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer bg-transparent d-flex flex-wrap gap-2 justify-content-end p-3">
                <button type="reset" class="btn btn-soft"><i class="bi bi-eraser me-1"></i>清空選取</button>
                <button type="submit" class="btn btn-danger"><i class="bi bi-trash me-1"></i>確定刪除</button>
            </div>
        </form>
    </div>

    <!-- 新增會員 -->
    <div class="col-xl-5">
        <div class="card h-100">
            <div class="card-header">
                <i class="bi bi-person-plus text-primary me-2"></i>新增會員
            </div>
            <div class="card-body">
                <div class="alert alert-brand d-flex gap-2 py-2 small" role="note">
                    <i class="bi bi-info-circle-fill"></i>
                    <span>請設定要註冊的帳號及密碼（最長 12 個字元）</span>
                </div>

                <form onsubmit="event.preventDefault(); reg();" novalidate>
                    <div class="mb-3">
                        <label class="form-label" for="acc">
                            <span class="badge text-bg-brand me-1">Step 1</span>登入帳號
                        </label>
                        <input type="text" class="form-control" name="acc" id="acc" maxlength="12" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="pw">
                            <span class="badge text-bg-brand me-1">Step 2</span>登入密碼
                        </label>
                        <input type="password" class="form-control" name="pw" id="pw" maxlength="12" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="pw2">
                            <span class="badge text-bg-brand me-1">Step 3</span>再次確認密碼
                        </label>
                        <input type="password" class="form-control" name="pw2" id="pw2" maxlength="12" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label" for="email">
                            <span class="badge text-bg-brand me-1">Step 4</span>電子信箱
                        </label>
                        <input type="email" class="form-control" name="email" id="email"
                               placeholder="忘記密碼時使用" required>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary flex-fill">
                            <i class="bi bi-plus-lg me-1"></i>新增
                        </button>
                        <button type="button" class="btn btn-soft"
                                onclick="$('#acc,#pw,#pw2,#email').val('')">
                            <i class="bi bi-eraser me-1"></i>清除
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function notify(msg, type) {
        if (window.hpToast) { window.hpToast(msg, type); } else { alert(msg); }
    }

    function reg() {
        var user = {
            'acc': $("#acc").val(),
            'pw': $("#pw").val(),
            'pw2': $("#pw2").val(),
            'email': $("#email").val()
        };

        if (user.acc === "" || user.pw === "" || user.pw2 === "" || user.email === "") {
            notify("不可空白", "warning");
        } else if (user.pw !== user.pw2) {
            notify("密碼錯誤", "danger");
        } else {
            $.get("api/chk_acc.php", user, function (res) {
                if (parseInt(res) > 0) {
                    notify("帳號重複", "danger");
                } else {
                    $.post("api/reg.php", user, function () {
                        location.reload();
                    });
                }
            });
        }
    }
</script>
