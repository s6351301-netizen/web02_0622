<?php
/**
 * 問卷管理：新增問卷（含多個選項）與開關前台顯示
 */
$ques = $Que->all(['main_id' => 0]);
?>

<div class="row g-4">
    <!-- 新增問卷 -->
    <div class="col-xl-5">
        <form action="./api/add_que.php" method="post" class="card h-100 needs-validation" novalidate>
            <div class="card-header">
                <i class="bi bi-plus-circle text-primary me-2"></i>新增問卷
            </div>

            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label" for="name">問卷名稱</label>
                    <input type="text" class="form-control" name="name" id="name"
                           placeholder="例如：你最常做什麼運動來促進健康體能呢?" required>
                    <div class="invalid-feedback">請輸入問卷名稱</div>
                </div>

                <label class="form-label">問卷選項</label>
                <div id="optionList" class="d-grid gap-2 mb-2">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-record-circle"></i></span>
                        <input type="text" class="form-control" name="option[]" placeholder="選項內容">
                        <button type="button" class="btn btn-outline-secondary js-remove" aria-label="移除此選項">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>
                </div>

                <button type="button" class="btn btn-soft btn-sm" onclick="more()">
                    <i class="bi bi-plus-lg me-1"></i>更多選項
                </button>

                <div class="form-text mt-2">
                    <i class="bi bi-info-circle me-1"></i>留空的選項不會被建立；新問卷預設為關閉，需手動開啟。
                </div>
            </div>

            <div class="card-footer bg-transparent d-flex gap-2 justify-content-end p-3">
                <button type="reset" class="btn btn-soft"><i class="bi bi-eraser me-1"></i>清空</button>
                <button type="submit" class="btn btn-primary"><i class="bi bi-check2-circle me-1"></i>新增</button>
            </div>
        </form>
    </div>

    <!-- 問卷列表 -->
    <div class="col-xl-7">
        <div class="card h-100">
            <div class="card-header d-flex align-items-center justify-content-between">
                <span><i class="bi bi-clipboard2-pulse text-primary me-2"></i>問卷列表</span>
                <span class="badge text-bg-brand">共 <?= count($ques) ?> 份</span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 hp-table-min">
                    <thead>
                        <tr>
                            <th scope="col" class="text-center" style="width:64px">#</th>
                            <th scope="col">問卷名稱</th>
                            <th scope="col" class="text-center" style="width:90px">投票數</th>
                            <th scope="col" class="text-center" style="width:150px">前台開放</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($ques)): ?>
                            <tr>
                                <td colspan="4">
                                    <div class="hp-empty"><i class="bi bi-clipboard2-x"></i>尚未建立任何問卷</div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($ques as $idx => $que): ?>
                                <?php
                                $qid  = (int) $que['id'];
                                $open = ($que['sh'] == 1);
                                $opts = $Que->count(['main_id' => $qid]);
                                ?>
                                <tr>
                                    <td class="text-center hp-text-muted"><?= $idx + 1 ?></td>
                                    <td>
                                        <div class="fw-semibold"><?= e($que['text']) ?></div>
                                        <small class="hp-text-muted">
                                            <i class="bi bi-list-ul me-1"></i><?= (int) $opts ?> 個選項
                                            <span class="mx-1">|</span>
                                            <a href="index.php?do=result&id=<?= $qid ?>" target="_blank" rel="noopener">
                                                查看結果<i class="bi bi-box-arrow-up-right ms-1"></i>
                                            </a>
                                        </small>
                                    </td>
                                    <td class="text-center fw-bold text-primary"><?= (int) $que['vote'] ?></td>
                                    <td class="text-center">
                                        <div class="form-check form-switch d-inline-flex align-items-center gap-2 m-0">
                                            <input class="form-check-input m-0" type="checkbox" role="switch"
                                                   id="sw<?= $qid ?>" <?= $open ? 'checked' : '' ?>
                                                   onchange="active(<?= $qid ?>, this)">
                                            <label class="form-check-label small" for="sw<?= $qid ?>"
                                                   id="lbl<?= $qid ?>">
                                                <?= $open ? '開放中' : '已關閉' ?>
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    /* 新增選項欄位 */
    function more() {
        var html =
            '<div class="input-group">' +
            '<span class="input-group-text"><i class="bi bi-record-circle"></i></span>' +
            '<input type="text" class="form-control" name="option[]" placeholder="選項內容">' +
            '<button type="button" class="btn btn-outline-secondary js-remove" aria-label="移除此選項">' +
            '<i class="bi bi-x-lg"></i></button>' +
            '</div>';
        $("#optionList").append(html);
        $("#optionList .form-control").last().focus();
    }

    /* 移除選項欄位（至少保留一組） */
    $("#optionList").on("click", ".js-remove", function () {
        if ($("#optionList .input-group").length > 1) {
            $(this).closest(".input-group").remove();
        } else {
            $(this).siblings(".form-control").val("");
        }
    });

    /* 切換問卷開放狀態 */
    function active(id, el) {
        $.post("./api/active_que.php", { id: id }, function () {
            $("#lbl" + id).text(el.checked ? "開放中" : "已關閉");
            if (window.hpToast) {
                window.hpToast(el.checked ? "已開放此問卷" : "已關閉此問卷", el.checked ? "success" : "secondary");
            }
        });
    }
</script>
