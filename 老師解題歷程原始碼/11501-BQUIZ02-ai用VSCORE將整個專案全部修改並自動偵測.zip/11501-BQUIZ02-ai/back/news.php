<?php
/**
 * 最新文章管理：切換顯示狀態、標記刪除（軟刪除）
 */
$all   = $News->count(['del' => 0]);
$div   = 3;
$pages = ceil($all / $div);
$now   = (int) ($_GET['p'] ?? 1);
$start = ($now - 1) * $div;
$rows  = $News->all(['del' => 0], " limit $start,$div");
?>

<form action="./api/edit_news.php" method="post" class="card"
      onsubmit="return confirmSubmit();">
    <div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2">
        <span>
            <i class="bi bi-list-check text-primary me-2"></i>文章列表
            <span class="badge text-bg-brand ms-2">共 <?= (int) $all ?> 篇</span>
        </span>
        <a class="btn btn-primary btn-sm" href="?do=add_news">
            <i class="bi bi-file-earmark-plus me-1"></i>新增文章
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0 hp-table-min">
            <thead>
                <tr>
                    <th scope="col" class="text-center" style="width:72px">編號</th>
                    <th scope="col">標題</th>
                    <th scope="col" class="text-center" style="width:120px">顯示</th>
                    <th scope="col" class="text-center" style="width:100px">刪除</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="4">
                            <div class="hp-empty"><i class="bi bi-inbox"></i>目前沒有文章</div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $idx => $row): ?>
                        <?php $rid = (int) $row['id']; ?>
                        <tr>
                            <td class="text-center hp-text-muted"><?= $start + 1 + $idx ?></td>
                            <td>
                                <div class="fw-semibold"><?= e($row['title']) ?></div>
                                <small class="hp-text-muted">
                                    <i class="bi bi-tag me-1"></i><?= e($row['type']) ?>
                                    <span class="mx-1">|</span>
                                    <i class="bi bi-hand-thumbs-up me-1"></i><?= (int) $row['good'] ?>
                                </small>
                                <input type="hidden" name="id[]" value="<?= $rid ?>">
                            </td>
                            <td class="text-center">
                                <div class="form-check form-switch d-inline-block">
                                    <input class="form-check-input" type="checkbox" role="switch"
                                           name="sh[]" value="<?= $rid ?>"
                                           id="sh<?= $rid ?>" <?= ($row['sh'] == 1) ? 'checked' : '' ?>>
                                    <label class="form-check-label visually-hidden" for="sh<?= $rid ?>">
                                        顯示於前台
                                    </label>
                                </div>
                            </td>
                            <td class="text-center">
                                <input class="form-check-input js-del" type="checkbox" name="del[]"
                                       value="<?= $rid ?>" aria-label="刪除文章 <?= e($row['title']) ?>">
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="card-footer bg-transparent d-flex flex-wrap align-items-center justify-content-between gap-3 p-3">
        <?php if ($pages > 1): ?>
            <nav aria-label="文章管理分頁">
                <ul class="pagination pagination-sm mb-0">
                    <li class="page-item<?= $now <= 1 ? ' disabled' : '' ?>">
                        <a class="page-link" href="?do=news&p=<?= $now - 1 ?>" aria-label="上一頁">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                        <li class="page-item<?= $i === $now ? ' active' : '' ?>">
                            <a class="page-link" href="?do=news&p=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item<?= $now >= $pages ? ' disabled' : '' ?>">
                        <a class="page-link" href="?do=news&p=<?= $now + 1 ?>" aria-label="下一頁">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php else: ?>
            <span class="small hp-text-muted">
                <i class="bi bi-info-circle me-1"></i>修改僅套用於目前頁面所列文章
            </span>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary ms-auto">
            <i class="bi bi-save me-1"></i>確定修改
        </button>
    </div>
</form>

<script>
    function confirmSubmit() {
        if ($(".js-del:checked").length > 0) {
            return confirm("已勾選刪除的文章將不再顯示於列表，確定要繼續嗎？");
        }
        return true;
    }
</script>
