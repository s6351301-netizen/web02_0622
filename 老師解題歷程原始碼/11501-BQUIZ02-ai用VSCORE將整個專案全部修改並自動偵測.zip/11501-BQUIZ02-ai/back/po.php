<?php
/**
 * 分類網誌管理（籌備中）
 * ------------------------------------------------------------------
 * 原專案後台選單中的「分類網誌」未建立對應頁面，點選後會落回管理首頁。
 * 此頁提供明確說明與替代入口。
 */
$HP_SOON_DESC = '文章分類目前固定為「健康新知、菸害防制、癌症防治、慢性病防治」四類，'
    . '可於「新增文章」時選擇。自訂分類的管理介面尚未開放。';
$HP_SOON_LINKS = [
    ['href' => '?do=add_news', 'icon' => 'bi-file-earmark-plus', 'label' => '新增文章', 'class' => 'btn-primary'],
    ['href' => '?do=news',     'icon' => 'bi-list-check',        'label' => '文章管理'],
    ['href' => 'index.php?do=po', 'icon' => 'bi-box-arrow-up-right', 'label' => '檢視前台分類網誌'],
];
include "./inc/coming_soon.php";
