<?php
/**
 * 新增文章
 */
$hpTypes = ['健康新知', '菸害防治', '癌症防治', '慢性病防治'];
?>

<div class="row justify-content-center">
    <div class="col-xl-9">
        <form action="./api/save_news.php" method="post" class="card needs-validation" novalidate>
            <div class="card-header d-flex align-items-center justify-content-between">
                <span><i class="bi bi-file-earmark-plus text-primary me-2"></i>文章內容</span>
                <a class="btn btn-sm btn-soft" href="?do=news">
                    <i class="bi bi-arrow-left me-1"></i>返回列表
                </a>
            </div>

            <div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label" for="title">文章標題</label>
                        <input type="text" class="form-control form-control-lg" name="title" id="title"
                               placeholder="請輸入文章標題" required>
                        <div class="invalid-feedback">請輸入文章標題</div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label" for="type">文章分類</label>
                        <select class="form-select form-select-lg" name="type" id="type">
                            <?php foreach ($hpTypes as $type): ?>
                                <option value="<?= e($type) ?>"><?= e($type) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="form-label" for="content">文章內容</label>
                        <textarea class="form-control" name="content" id="content" rows="14"
                                  placeholder="請輸入文章內容，換行會直接呈現於前台" required></textarea>
                        <div class="invalid-feedback">請輸入文章內容</div>
                        <div class="form-text d-flex justify-content-between">
                            <span><i class="bi bi-lightbulb me-1"></i>新增後預設為「顯示」狀態，可於文章管理調整</span>
                            <span><span id="charCount">0</span> 字</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-footer bg-transparent d-flex flex-wrap gap-2 justify-content-end p-3">
                <button type="reset" class="btn btn-soft"><i class="bi bi-arrow-counterclockwise me-1"></i>重置</button>
                <button type="submit" class="btn btn-primary px-4"><i class="bi bi-check2-circle me-1"></i>新增</button>
            </div>
        </form>
    </div>
</div>

<script>
    $("#content").on("input", function () {
        $("#charCount").text($(this).val().length);
    });
    $("form").on("reset", function () {
        setTimeout(function () { $("#charCount").text(0); }, 0);
    });
</script>
