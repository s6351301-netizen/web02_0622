<?php
/**
 * 講座訊息管理（籌備中）
 * ------------------------------------------------------------------
 * 原專案後台選單中的「講座訊息」未建立對應頁面，點選後會落回管理首頁。
 */
$HP_SOON_DESC = '講座場次的建立、報名名單與提醒通知等管理功能規劃中，'
    . '開放後可於此處維護場次資訊，並同步顯示於前台「講座訊息」頁面。';
$HP_SOON_LINKS = [
    ['href' => '?do=news',        'icon' => 'bi-newspaper',          'label' => '改以文章公告', 'class' => 'btn-primary'],
    ['href' => 'index.php?do=know', 'icon' => 'bi-box-arrow-up-right', 'label' => '檢視前台頁面'],
];
include "./inc/coming_soon.php";
